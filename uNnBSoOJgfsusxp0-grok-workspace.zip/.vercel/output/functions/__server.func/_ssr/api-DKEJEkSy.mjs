import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/api-DKEJEkSy.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var searchPlaces_createServerFn_handler = createServerRpc({
	id: "22dd64c431f956509af6c52f78efe2657ba2fec4a05476d6a2265baf114dc3cc",
	name: "searchPlaces",
	filename: "src/lib/api.ts"
}, (opts) => searchPlaces.__executeServer(opts));
var searchPlaces = createServerFn({ method: "POST" }).validator((input) => input).handler(searchPlaces_createServerFn_handler, async ({ data }) => {
	const q = data.q.trim();
	if (q.length < 2) return [];
	const { searchPhoton } = await import("./plan.server-r2KvWq4f.mjs");
	return searchPhoton(q, data.lat != null && data.lng != null ? {
		lat: data.lat,
		lng: data.lng
	} : void 0);
});
var reverseGeocode_createServerFn_handler = createServerRpc({
	id: "9adbf68a15d15b1c3afe18f38f6440b0816972ca3405db633a16ff37230a28af",
	name: "reverseGeocode",
	filename: "src/lib/api.ts"
}, (opts) => reverseGeocode.__executeServer(opts));
var reverseGeocode = createServerFn({ method: "POST" }).validator((input) => input).handler(reverseGeocode_createServerFn_handler, async ({ data }) => {
	const { reversePlace } = await import("./plan.server-r2KvWq4f.mjs");
	return { label: await reversePlace(data) };
});
var planSafeRoute_createServerFn_handler = createServerRpc({
	id: "3bd061db8a0a57ed781101163938496f0440fce73682086d418f6b4f49681910",
	name: "planSafeRoute",
	filename: "src/lib/api.ts"
}, (opts) => planSafeRoute.__executeServer(opts));
var planSafeRoute = createServerFn({ method: "POST" }).validator((input) => input).handler(planSafeRoute_createServerFn_handler, async ({ data }) => {
	const { planSafeWalk } = await import("./plan.server-r2KvWq4f.mjs");
	return planSafeWalk(data);
});
//#endregion
export { planSafeRoute_createServerFn_handler, reverseGeocode_createServerFn_handler, searchPlaces_createServerFn_handler };
