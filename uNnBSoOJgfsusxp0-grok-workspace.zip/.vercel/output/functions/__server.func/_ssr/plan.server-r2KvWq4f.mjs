import { n as destinationPoint, o as routesSimilar, r as haversineMeters, s as sampleAlong, t as bboxOf } from "./geo-BlQAfLw3.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/plan.server-r2KvWq4f.js
function clamp(n, min = 0, max = 100) {
	return Math.max(min, Math.min(max, n));
}
function nearestAmenity(point, amenities, kinds) {
	let best = Infinity;
	for (const a of amenities) {
		if (!kinds.includes(a.kind)) continue;
		best = Math.min(best, haversineMeters(point, a));
	}
	return best;
}
function countWithin(point, points, radius) {
	let n = 0;
	for (const p of points) if (haversineMeters(point, p) <= radius) n += 1;
	return n;
}
function isolationFromSteps(steps) {
	if (steps.length === 0) return 55;
	const unnamed = steps.filter((s) => !s.name || s.name === "-").length;
	const quiet = steps.filter((s) => /alley|path|track|steps|footway|service/i.test(s.name + " " + s.instruction)).length;
	const namedRatio = 1 - unnamed / steps.length;
	const quietRatio = quiet / steps.length;
	return clamp(namedRatio * 100 - quietRatio * 28);
}
function scoreCandidate(input) {
	const samples = sampleAlong(input.geometry, 75);
	const lampPts = input.lamps;
	const peoplePts = input.amenities.filter((a) => a.kind === "shop" || a.kind === "pharmacy" || a.kind === "clinic").map((a) => ({
		lat: a.lat,
		lng: a.lng
	}));
	const helpKinds = [
		"police",
		"hospital",
		"clinic",
		"fire",
		"pharmacy"
	];
	let litHits = 0;
	let peopleHits = 0;
	let helpAcc = 0;
	for (const p of samples) {
		if (lampPts.length === 0) litHits += 0;
		else if (countWithin(p, lampPts, 45) > 0) litHits += 1;
		if (countWithin(p, peoplePts, 90) > 0) peopleHits += 1;
		const help = nearestAmenity(p, input.amenities, helpKinds);
		helpAcc += help === Infinity ? 0 : clamp(100 - help / 9, 0, 100);
	}
	const n = Math.max(1, samples.length);
	const lampCoverage = lampPts.length >= 6 ? litHits / n * 100 : null;
	const namedStreet = isolationFromSteps(input.steps);
	const lighting = lampCoverage == null ? namedStreet : lampCoverage * .7 + namedStreet * .3;
	const populated = peoplePts.length > 0 ? peopleHits / n * 100 : namedStreet * .85;
	const emergency = input.amenities.some((a) => helpKinds.includes(a.kind)) ? helpAcc / n : 52;
	const isolation = namedStreet;
	let hazardPenalty = 0;
	const reasons = [];
	for (const h of input.hazards) for (const p of samples) if (haversineMeters(p, h) < 50) {
		hazardPenalty += 12;
		break;
	}
	const breakdown = {
		lighting: Math.round(clamp(lighting)),
		populated: Math.round(clamp(populated)),
		emergency: Math.round(clamp(emergency)),
		isolation: Math.round(clamp(isolation))
	};
	const wLight = input.night ? .4 : .2;
	const wPop = input.night ? .22 : .24;
	const wEm = .2;
	const wIso = input.night ? .18 : .36;
	const raw = breakdown.lighting * wLight + breakdown.populated * wPop + breakdown.emergency * wEm + breakdown.isolation * wIso - Math.min(36, hazardPenalty);
	const score = Math.round(clamp(raw));
	if (breakdown.lighting >= 70) reasons.push("Better lighting along this walk");
	else if (input.night && breakdown.lighting < 45) reasons.push("Dim stretches after dark — stay on named streets");
	if (breakdown.populated >= 65) reasons.push("Passes shops and active frontage");
	else if (breakdown.populated < 40) reasons.push("Quieter blocks with fewer people around");
	if (breakdown.emergency >= 55) reasons.push("Help is relatively close (clinic, pharmacy, or police)");
	if (breakdown.isolation >= 70) reasons.push("Prefers named roads over alleys and paths");
	else if (breakdown.isolation < 45) reasons.push("Includes quieter paths that Google Maps often treats as shortcuts");
	if (hazardPenalty > 0) reasons.push("A reported hazard sits near this path");
	if (reasons.length === 0) reasons.push("OpenStreetMap walking path with a balanced safety score");
	return {
		distance: input.distance,
		duration: input.duration,
		geometry: input.geometry,
		steps: input.steps,
		score,
		breakdown,
		reasons: reasons.slice(0, 3)
	};
}
function assignKinds(routes) {
	if (routes.length === 0) return [];
	const fastest = routes.reduce((a, b) => a.duration <= b.duration ? a : b);
	const safest = routes.reduce((a, b) => a.score >= b.score ? a : b);
	const maxDur = Math.max(...routes.map((r) => r.duration), 1);
	const minDur = Math.min(...routes.map((r) => r.duration), 1);
	const span = Math.max(1, maxDur - minDur);
	const balanced = routes.reduce((best, r) => {
		const timeNorm = 100 - (r.duration - minDur) / span * 100;
		const mix = r.score * .58 + timeNorm * .42;
		const bestTime = 100 - (best.duration - minDur) / span * 100;
		return mix > best.score * .58 + bestTime * .42 ? r : best;
	});
	const picked = [{
		kind: "safest",
		route: safest
	}];
	if (balanced !== safest) picked.push({
		kind: "balanced",
		route: balanced
	});
	if (fastest !== safest && fastest !== balanced) picked.push({
		kind: "fastest",
		route: fastest
	});
	else if (picked.length === 1 && routes.length > 1) {
		const other = routes.find((r) => r !== safest);
		if (other) picked.push({
			kind: "fastest",
			route: other
		});
	}
	return picked.map((p, i) => ({
		...p.route,
		kind: p.kind,
		id: `${p.kind}-${i}`
	}));
}
function fallbackBrief(route, night) {
	const headline = route.score >= 78 ? "A well-supported walking route" : route.score >= 58 ? night ? "Usable at night, with a few quieter stretches" : "A reasonable walk with a few quiet blocks" : "Take extra care — this is the best path we could score";
	const summary = route.reasons.join(". ") + ".";
	const watchOuts = [
		...route.breakdown.lighting < 50 ? ["Lighting is uneven — keep to the wider named streets."] : [],
		...route.breakdown.isolation < 50 ? ["Avoid slipping into alleys even if they look shorter."] : [],
		...night ? ["After dark, prefer blocks with shops still open."] : []
	].slice(0, 3);
	return {
		headline,
		summary,
		watchOuts: watchOuts.length ? watchOuts : ["Stay on the highlighted path."],
		tips: [
			"Share your live location with someone you trust before you start.",
			"If a street feels wrong, leave the shortcut and return to the last named road.",
			"Pharmacies, hospitals, and police posts are marked on the map when OpenStreetMap has them."
		]
	};
}
var USER_AGENT = "SafePath/1.0 (open-source pedestrian safety routing)";
function instructionFor(step) {
	const type = step.maneuver?.type ?? "continue";
	const modifier = step.maneuver?.modifier;
	const name = step.name && step.name !== "-" ? step.name : "";
	const onto = name ? ` onto ${name}` : "";
	if (type === "depart") return name ? `Start on ${name}` : "Start walking on the highlighted path";
	if (type === "arrive") return "You have arrived";
	if (type === "roundabout" || type === "rotary") return `Enter the roundabout${onto}`;
	if (type === "turn" || type === "end of road" || type === "fork" || type === "off ramp") return `Turn ${modifier ? modifier.replace(/_/g, " ") : "ahead"}${onto}`;
	if (type === "new name" || type === "continue") return name ? `Continue on ${name}` : "Continue straight";
	return name ? `Continue on ${name}` : "Continue";
}
function stepsFrom(route) {
	return (route.legs?.flatMap((l) => l.steps ?? []) ?? []).map((s) => {
		const loc = s.maneuver?.location;
		return {
			instruction: instructionFor(s),
			distance: s.distance,
			duration: s.duration,
			name: s.name && s.name !== "-" ? s.name : "",
			location: loc ? {
				lat: loc[1],
				lng: loc[0]
			} : {
				lat: 0,
				lng: 0
			}
		};
	});
}
function geometryFrom(route) {
	return (route.geometry?.coordinates ?? []).map(([lng, lat]) => ({
		lat,
		lng
	}));
}
async function fetchJson(url, init, ms) {
	const res = await fetch(url, {
		...init,
		signal: AbortSignal.timeout(ms),
		headers: {
			Accept: "application/json",
			"User-Agent": USER_AGENT,
			...init?.headers ?? {}
		}
	});
	if (!res.ok) throw new Error(`Request failed (${res.status})`);
	return res.json();
}
async function osrmRoute(points, alternatives = false) {
	const json = await fetchJson(`https://router.project-osrm.org/route/v1/foot/${points.map((p) => `${p.lng},${p.lat}`).join(";")}?${new URLSearchParams({
		overview: "full",
		geometries: "geojson",
		steps: "true",
		alternatives: alternatives ? "true" : "false"
	}).toString()}`, void 0, 12e3);
	if (json.code && json.code !== "Ok") return [];
	return json.routes ?? [];
}
function amenityKind(tags) {
	const amenity = tags.amenity;
	const shop = tags.shop;
	if (tags.highway === "street_lamp") return "lamp";
	if (amenity === "police") return "police";
	if (amenity === "hospital") return "hospital";
	if (amenity === "clinic") return "clinic";
	if (amenity === "pharmacy") return "pharmacy";
	if (amenity === "fire_station") return "fire";
	if (shop === "convenience" || shop === "supermarket" || amenity === "marketplace") return "shop";
	return null;
}
async function fetchSafetyLayer(points) {
	const box = bboxOf(points, 220);
	const bbox = `${box.south},${box.west},${box.north},${box.east}`;
	const query = `[out:json][timeout:12];
(
  node["highway"="street_lamp"](${bbox});
  node["amenity"="police"](${bbox});
  node["amenity"="hospital"](${bbox});
  node["amenity"="clinic"](${bbox});
  node["amenity"="pharmacy"](${bbox});
  node["amenity"="fire_station"](${bbox});
  node["shop"="convenience"](${bbox});
  node["shop"="supermarket"](${bbox});
);
out center 250;`;
	const endpoints = ["https://overpass-api.de/api/interpreter", "https://overpass.kumi.systems/api/interpreter"];
	let json = null;
	for (const endpoint of endpoints) try {
		json = await fetchJson(endpoint, {
			method: "POST",
			headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
			body: new URLSearchParams({ data: query })
		}, 14e3);
		break;
	} catch {
		json = null;
	}
	const amenities = [];
	const lamps = [];
	for (const el of json?.elements ?? []) {
		const lat = el.lat ?? el.center?.lat;
		const lng = el.lon ?? el.center?.lon;
		if (lat == null || lng == null) continue;
		const kind = amenityKind(el.tags ?? {});
		if (!kind) continue;
		if (kind === "lamp") {
			lamps.push({
				lat,
				lng
			});
			continue;
		}
		amenities.push({
			id: String(el.id),
			kind,
			name: el.tags?.name ?? kind,
			lat,
			lng
		});
	}
	return {
		amenities: amenities.slice(0, 80),
		lamps: lamps.slice(0, 400)
	};
}
function pickVia(origin, dest, amenities) {
	const direct = haversineMeters(origin, dest);
	if (direct < 250) return null;
	const mid = {
		lat: (origin.lat + dest.lat) / 2,
		lng: (origin.lng + dest.lng) / 2
	};
	const rank = {
		police: 5,
		hospital: 4,
		fire: 4,
		pharmacy: 3,
		clinic: 3,
		shop: 2,
		lamp: 0
	};
	let best = null;
	for (const a of amenities) {
		if (haversineMeters(origin, a) + haversineMeters(a, dest) > direct * 1.38) continue;
		if (haversineMeters(a, origin) < 80 || haversineMeters(a, dest) < 80) continue;
		const towardMid = 1 / (1 + haversineMeters(a, mid) / 400);
		const score = (rank[a.kind] ?? 0) * 12 + towardMid * 20;
		if (!best || score > best.score) best = {
			a,
			score
		};
	}
	if (best) return {
		lat: best.a.lat,
		lng: best.a.lng
	};
	const br = Math.atan2(dest.lng - origin.lng, dest.lat - origin.lat) * (180 / Math.PI);
	return destinationPoint(mid, br + 90, Math.min(280, direct * .12));
}
async function briefWithGrok(input) {
	const fallback = fallbackBrief(input.route, input.night);
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return fallback;
	const prompt = `You are SafePath, a pedestrian-safety advisor. Google Maps optimizes for time; we optimize for a safer walk.

Walk: ${input.originLabel} → ${input.destLabel}
Time: ${input.night ? "night / low light" : "daytime"}
Distance: ${Math.round(input.route.distance)} m, duration ${Math.round(input.route.duration / 60)} min
Safety score: ${input.route.score}/100
Lighting ${input.route.breakdown.lighting}, populated ${input.route.breakdown.populated}, emergency access ${input.route.breakdown.emergency}, named-street quality ${input.route.breakdown.isolation}
Notes: ${input.route.reasons.join("; ")}

Reply with compact JSON only:
{"headline":"...","summary":"2 sentences","watchOuts":["..."],"tips":["..."]}
No markdown. Be specific and calm. Do not invent street names that were not provided.`;
	try {
		const res = await fetch("https://api.x.ai/v1/chat/completions", {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				Authorization: `Bearer ${apiKey}`
			},
			body: JSON.stringify({
				model: "grok-4.5",
				temperature: .3,
				max_tokens: 420,
				messages: [{
					role: "user",
					content: prompt
				}]
			}),
			signal: AbortSignal.timeout(18e3)
		});
		if (!res.ok) return fallback;
		let text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
		const fence = text.match(/\{[\s\S]*\}/);
		if (fence) text = fence[0];
		const parsed = JSON.parse(text);
		if (!parsed.headline || !parsed.summary) return fallback;
		return {
			headline: String(parsed.headline).slice(0, 140),
			summary: String(parsed.summary).slice(0, 420),
			watchOuts: (parsed.watchOuts ?? []).map(String).slice(0, 4),
			tips: (parsed.tips ?? []).map(String).slice(0, 4)
		};
	} catch {
		return fallback;
	}
}
async function planSafeWalk(input) {
	const direct = haversineMeters(input.origin, input.destination);
	if (direct < 40) throw new Error("Origin and destination are too close to plan a walk.");
	if (direct > 25e3) throw new Error("That's farther than a reasonable walk. Pick a closer destination.");
	const primary = await osrmRoute([input.origin, input.destination], true);
	if (primary.length === 0) throw new Error("No walking path found between those places. Try a nearby street or landmark.");
	const layer = await fetchSafetyLayer([
		input.origin,
		input.destination,
		...primary.flatMap((r) => geometryFrom(r))
	]);
	const via = pickVia(input.origin, input.destination, layer.amenities);
	let viaRoutes = [];
	if (via) try {
		viaRoutes = await osrmRoute([
			input.origin,
			via,
			input.destination
		], false);
	} catch {
		viaRoutes = [];
	}
	const merged = [];
	for (const r of [...primary, ...viaRoutes]) {
		const geo = geometryFrom(r);
		if (geo.length < 2) continue;
		if (merged.some((m) => routesSimilar(geometryFrom(m), geo))) continue;
		merged.push(r);
	}
	const routes = assignKinds(merged.map((r) => scoreCandidate({
		geometry: geometryFrom(r),
		steps: stepsFrom(r),
		distance: r.distance,
		duration: r.duration,
		amenities: layer.amenities,
		lamps: layer.lamps,
		hazards: input.hazards,
		night: input.night
	})));
	if (routes.length === 0) throw new Error("Couldn't score a walking path. Try again in a moment.");
	const preferred = routes.find((r) => r.kind === "safest") ?? routes[0];
	const brief = await briefWithGrok({
		originLabel: input.originLabel,
		destLabel: input.destLabel,
		night: input.night,
		route: preferred
	});
	return {
		routes,
		amenities: layer.amenities.filter((a) => a.kind !== "lamp").slice(0, 48),
		brief,
		night: input.night
	};
}
async function searchPhoton(q, bias) {
	const params = new URLSearchParams({
		q: q.trim(),
		limit: "6"
	});
	if (bias) {
		params.set("lat", String(bias.lat));
		params.set("lon", String(bias.lng));
	}
	try {
		return ((await fetchJson(`https://photon.komoot.io/api/?${params.toString()}`, void 0, 8e3)).features ?? []).map((f) => {
			const c = f.geometry?.coordinates;
			if (!c) return null;
			const p = f.properties ?? {};
			const name = p.name || p.street || "Place";
			const bits = [
				p.housenumber,
				p.street,
				p.city,
				p.state
			].filter(Boolean);
			return {
				id: String(p.osm_id ?? `${c[1]},${c[0]}`),
				name,
				label: bits.length ? `${name} — ${bits.join(", ")}` : name,
				lat: c[1],
				lng: c[0]
			};
		}).filter((x) => x != null);
	} catch {
		return searchNominatim(q);
	}
}
async function searchNominatim(q) {
	return (await fetchJson(`https://nominatim.openstreetmap.org/search?${new URLSearchParams({
		q: q.trim(),
		format: "jsonv2",
		limit: "6",
		addressdetails: "0"
	}).toString()}`, void 0, 9e3) ?? []).map((row) => ({
		id: String(row.place_id),
		name: row.display_name.split(",")[0] ?? row.display_name,
		label: row.display_name,
		lat: Number(row.lat),
		lng: Number(row.lon)
	}));
}
async function reversePlace(point) {
	try {
		const json = await fetchJson(`https://nominatim.openstreetmap.org/reverse?${new URLSearchParams({
			lat: String(point.lat),
			lon: String(point.lng),
			format: "jsonv2"
		}).toString()}`, void 0, 8e3);
		const a = json.address ?? {};
		return [
			a.road,
			a.neighbourhood || a.suburb,
			a.city || a.town || a.village
		].filter(Boolean).join(", ") || json.name || json.display_name || `${point.lat.toFixed(4)}, ${point.lng.toFixed(4)}`;
	} catch {
		return `${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`;
	}
}
//#endregion
export { planSafeWalk, reversePlace, searchPhoton };
