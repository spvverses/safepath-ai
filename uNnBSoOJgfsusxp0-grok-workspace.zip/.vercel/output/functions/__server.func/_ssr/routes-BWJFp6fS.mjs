import { i as __toESM } from "../_runtime.mjs";
import { n as require_react } from "../_libs/@radix-ui/react-compose-refs+[...].mjs";
import { n as require_jsx_runtime } from "../_libs/radix-ui__react-context+react.mjs";
import { n as Slot } from "../_libs/@radix-ui/react-primitive+[...].mjs";
import { n as TSS_SERVER_FUNCTION, r as getServerFnById, t as createServerFn } from "./ssr.mjs";
import { a as remainingDistance, i as nearestOnPath } from "./geo-BlQAfLw3.mjs";
import { _ as ArrowLeft, a as Search, c as Navigation, d as MapPinned, f as MapPin, g as Flag, h as Footprints, i as ShieldCheck, l as Moon, m as Lamp, n as Siren, o as Radio, p as LocateFixed, r as Shield, s as OctagonX, u as MoonStar } from "../_libs/lucide-react.mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { n as clsx, t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as create } from "../_libs/zustand.mjs";
import { n as SwitchThumb, t as Switch$1 } from "../_libs/@radix-ui/react-switch+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-BWJFp6fS.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var ROUTE_STYLE = {
	safest: {
		color: "#d8dee6",
		weight: 6,
		opacity: .95
	},
	balanced: {
		color: "#8fa898",
		weight: 5,
		opacity: .85
	},
	fastest: {
		color: "#6b7380",
		weight: 4,
		opacity: .7,
		dashArray: "8 10"
	}
};
function amenityColor(kind) {
	if (kind === "police" || kind === "fire") return "#8fa898";
	if (kind === "hospital" || kind === "clinic" || kind === "pharmacy") return "#d8dee6";
	return "#9aa3ad";
}
function MapCanvas({ origin, destination, user, routes, selectedId, amenities, hazards, follow, onReady }) {
	const elRef = (0, import_react.useRef)(null);
	const mapRef = (0, import_react.useRef)(null);
	const layersRef = (0, import_react.useRef)(null);
	const userRef = (0, import_react.useRef)(null);
	const followRef = (0, import_react.useRef)(follow);
	followRef.current = follow;
	(0, import_react.useEffect)(() => {
		const el = elRef.current;
		if (!el) return;
		let cancelled = false;
		let map;
		let ro;
		(async () => {
			const L = await import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t()));
			if (cancelled || !elRef.current) return;
			map = L.map(el, {
				zoomControl: false,
				attributionControl: true,
				zoomSnap: .5
			}).setView(user ?? origin ?? {
				lat: 20.59,
				lng: 78.96
			}, user || origin ? 14 : 4);
			L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
				attribution: "&copy; <a href=\"https://www.openstreetmap.org/copyright\">OpenStreetMap</a> &copy; CARTO",
				subdomains: "abcd",
				maxZoom: 19
			}).addTo(map);
			L.control.zoom({ position: "topright" }).addTo(map);
			layersRef.current = L.layerGroup().addTo(map);
			userRef.current = L.layerGroup().addTo(map);
			mapRef.current = map;
			map.invalidateSize();
			ro = new ResizeObserver(() => map?.invalidateSize());
			ro.observe(el);
			onReady?.(() => map?.invalidateSize());
		})();
		return () => {
			cancelled = true;
			ro?.disconnect();
			map?.remove();
			mapRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		const map = mapRef.current;
		const group = layersRef.current;
		if (!map || !group) return;
		let cancelled = false;
		import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t())).then((L) => {
			if (cancelled || !mapRef.current || !layersRef.current) return;
			layersRef.current.clearLayers();
			const ordered = [...routes].sort((a, b) => a.id === selectedId ? 1 : b.id === selectedId ? -1 : 0);
			for (const route of ordered) {
				const style = ROUTE_STYLE[route.kind] ?? ROUTE_STYLE.balanced;
				const isSel = route.id === selectedId;
				L.polyline(route.geometry.map((p) => [p.lat, p.lng]), {
					color: style.color,
					weight: isSel ? style.weight + 1 : Math.max(3, style.weight - 1),
					opacity: isSel ? style.opacity : .35,
					dashArray: style.dashArray,
					lineCap: "round",
					lineJoin: "round"
				}).addTo(layersRef.current);
			}
			const pin = (point, label, fill) => {
				L.circleMarker([point.lat, point.lng], {
					radius: 8,
					color: "#f1eee8",
					weight: 2,
					fillColor: fill,
					fillOpacity: 1
				}).bindTooltip(label, {
					direction: "top",
					offset: [0, -8]
				}).addTo(layersRef.current);
			};
			if (origin) pin(origin, "Start", "#d8dee6");
			if (destination) pin(destination, "Destination", "#8fa898");
			for (const a of amenities) L.circleMarker([a.lat, a.lng], {
				radius: 5,
				color: amenityColor(a.kind),
				weight: 1,
				fillColor: amenityColor(a.kind),
				fillOpacity: .9
			}).bindTooltip(`${a.kind}: ${a.name}`, { direction: "top" }).addTo(layersRef.current);
			for (const h of hazards) L.circleMarker([h.lat, h.lng], {
				radius: 7,
				color: "#c77b6a",
				weight: 2,
				fillColor: "#c77b6a",
				fillOpacity: .35
			}).bindTooltip(h.note || h.kind, { direction: "top" }).addTo(layersRef.current);
			const fitPts = [];
			if (selectedId) {
				const sel = routes.find((r) => r.id === selectedId);
				if (sel) fitPts.push(...sel.geometry.map((p) => [p.lat, p.lng]));
			} else {
				if (origin) fitPts.push([origin.lat, origin.lng]);
				if (destination) fitPts.push([destination.lat, destination.lng]);
			}
			if (fitPts.length >= 2 && !followRef.current) mapRef.current.fitBounds(fitPts, {
				padding: [48, 48],
				maxZoom: 16
			});
			else if (fitPts.length === 1 && !followRef.current) mapRef.current.setView(fitPts[0], 15);
		});
		return () => {
			cancelled = true;
		};
	}, [
		routes,
		selectedId,
		amenities,
		hazards,
		origin,
		destination
	]);
	(0, import_react.useEffect)(() => {
		const group = userRef.current;
		const map = mapRef.current;
		if (!group || !map) return;
		let cancelled = false;
		import("../_libs/leaflet.mjs").then((n) => /* @__PURE__ */ __toESM(n.t())).then((L) => {
			if (cancelled || !userRef.current) return;
			userRef.current.clearLayers();
			if (!user) return;
			L.circleMarker([user.lat, user.lng], {
				radius: 18,
				color: "#d8dee6",
				weight: 0,
				fillColor: "#d8dee6",
				fillOpacity: .12
			}).addTo(userRef.current);
			L.circleMarker([user.lat, user.lng], {
				radius: 7,
				color: "#0b0d10",
				weight: 2,
				fillColor: "#f1eee8",
				fillOpacity: 1
			}).addTo(userRef.current);
			if (followRef.current) map.setView([user.lat, user.lng], Math.max(map.getZoom(), 16), { animate: true });
		});
		return () => {
			cancelled = true;
		};
	}, [user]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref: elRef,
		className: "map-root h-full w-full"
	});
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function formatDistance(meters) {
	if (meters < 1e3) return `${Math.round(meters)} m`;
	return `${(meters / 1e3).toFixed(meters >= 1e4 ? 0 : 1)} km`;
}
function formatDuration(seconds) {
	const s = Math.max(0, Math.round(seconds));
	const h = Math.floor(s / 3600);
	const m = Math.round(s % 3600 / 60);
	if (h <= 0) return `${Math.max(1, m)} min`;
	return m === 0 ? `${h} hr` : `${h} hr ${m} min`;
}
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[opacity,transform,background-color,color] duration-150 ease-out focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-fg hover:opacity-90",
			secondary: "bg-surface-2 text-fg shadow-[0_0_0_1px_rgba(241,238,232,0.08)] hover:bg-surface",
			ghost: "text-fg hover:bg-surface-2",
			outline: "bg-transparent text-fg shadow-[0_0_0_1px_rgba(241,238,232,0.12)] hover:bg-surface-2",
			danger: "bg-danger text-fg hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-xs",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		...props
	});
}
function Badge({ className, tone = "muted", children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium tracking-wide", tone === "muted" && "bg-surface-2 text-muted", tone === "safe" && "bg-safe/15 text-safe", tone === "warn" && "bg-warn/15 text-warn", tone === "danger" && "bg-danger/15 text-danger", tone === "fg" && "bg-primary/12 text-fg", className),
		children
	});
}
var KEY = "safepath.hazards.v1";
function loadHazards() {
	if (typeof window === "undefined") return [];
	try {
		const raw = window.localStorage.getItem(KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		return Array.isArray(parsed) ? parsed.slice(-80) : [];
	} catch {
		return [];
	}
}
function saveHazards(hazards) {
	if (typeof window === "undefined") return;
	window.localStorage.setItem(KEY, JSON.stringify(hazards.slice(-80)));
}
function isNightHour() {
	const h = (/* @__PURE__ */ new Date()).getHours();
	return h >= 19 || h < 6;
}
var useSafePath = create((set, get) => ({
	phase: "welcome",
	gps: "idle",
	night: isNightHour(),
	origin: null,
	destination: null,
	user: null,
	heading: null,
	routes: [],
	selectedId: null,
	amenities: [],
	brief: null,
	hazards: loadHazards(),
	planning: false,
	error: null,
	follow: false,
	setNight: (night) => set({ night }),
	setPhase: (phase) => set({
		phase,
		follow: phase === "navigate"
	}),
	setOrigin: (origin) => set({ origin }),
	setDestination: (destination) => set({ destination }),
	setUser: (user, heading) => set({
		user,
		heading: heading ?? get().heading
	}),
	setGps: (gps) => set({ gps }),
	setSelected: (id) => set({ selectedId: id }),
	applyPlan: (plan) => {
		const preferred = plan.routes.find((r) => r.kind === "safest") ?? plan.routes[0] ?? null;
		set({
			routes: plan.routes,
			amenities: plan.amenities,
			brief: plan.brief,
			selectedId: preferred?.id ?? null,
			phase: "results",
			planning: false,
			error: null,
			night: plan.night,
			follow: false
		});
	},
	setPlanning: (planning) => set({
		planning,
		error: planning ? null : get().error
	}),
	setError: (error) => set({
		error,
		planning: false
	}),
	addHazard: (kind, point, note) => {
		const hazard = {
			id: crypto.randomUUID(),
			lat: point.lat,
			lng: point.lng,
			kind,
			note,
			at: Date.now()
		};
		const hazards = [...get().hazards, hazard].slice(-80);
		saveHazards(hazards);
		set({ hazards });
	},
	resetPlan: () => set({
		routes: [],
		selectedId: null,
		brief: null,
		amenities: [],
		phase: "plan",
		error: null
	}),
	selectedRoute: () => {
		const { routes, selectedId } = get();
		return routes.find((r) => r.id === selectedId) ?? routes[0] ?? null;
	}
}));
var KIND_LABEL = {
	safest: "Safest",
	balanced: "Balanced",
	fastest: "Fastest"
};
var HAZARD_LABEL = {
	dark: "Poor lighting",
	isolated: "Isolated stretch",
	flood: "Flooding / water",
	other: "Other hazard"
};
function NavPanel() {
	const route = useSafePath((s) => s.selectedRoute());
	const user = useSafePath((s) => s.user);
	const origin = useSafePath((s) => s.origin);
	const destination = useSafePath((s) => s.destination);
	const setPhase = useSafePath((s) => s.setPhase);
	const addHazard = useSafePath((s) => s.addHazard);
	const gps = useSafePath((s) => s.gps);
	const pos = user ?? (origin ? {
		lat: origin.lat,
		lng: origin.lng
	} : null);
	const nav = (0, import_react.useMemo)(() => {
		if (!route || !pos) return {
			instruction: route?.steps[0]?.instruction ?? "Follow the highlighted path",
			remainingM: route?.distance ?? 0,
			remainingS: route?.duration ?? 0,
			off: false
		};
		const near = nearestOnPath(pos, route.geometry);
		const remainingM = remainingDistance(pos, route.geometry);
		const pace = route.distance > 0 ? route.duration / route.distance : 0;
		let walked = 0;
		let step = route.steps[0];
		for (const s of route.steps) {
			if (walked + s.distance >= near.along) {
				step = s;
				break;
			}
			walked += s.distance;
		}
		return {
			instruction: step?.instruction ?? "Continue on the safe path",
			remainingM,
			remainingS: remainingM * pace,
			off: near.dist > 55
		};
	}, [route, pos]);
	async function sos() {
		if (!pos) {
			toast("We don't have a location to share yet.");
			return;
		}
		const text = `I need help. My location: https://www.openstreetmap.org/?mlat=${pos.lat}&mlon=${pos.lng}#map=18/${pos.lat}/${pos.lng}`;
		try {
			if (navigator.share) await navigator.share({ text });
			else {
				await navigator.clipboard.writeText(text);
				toast("Location copied. Send it to someone you trust.");
			}
		} catch {
			try {
				await navigator.clipboard.writeText(text);
				toast("Location copied.");
			} catch {
				toast(text);
			}
		}
		window.location.href = "tel:112";
	}
	function mark(kind) {
		const point = pos ?? destination;
		if (!point) return;
		addHazard(kind, point, HAZARD_LABEL[kind]);
		toast("Hazard saved on this device for later walks.");
	}
	if (!route) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
					tone: gps === "active" ? "safe" : "muted",
					children: gps === "active" ? "Live location on" : "Location not following yet"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs tabular-nums text-muted",
					children: [
						formatDuration(nav.remainingS),
						" · ",
						formatDistance(nav.remainingM)
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium uppercase tracking-wider text-muted",
					children: "Next"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 font-display text-2xl leading-tight tracking-tight text-balance",
					"aria-live": "polite",
					children: nav.instruction
				}),
				nav.off && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 text-sm text-warn",
					children: "You are off the safe path. Return to the highlighted streets, or plan again from here."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "danger",
					onClick: () => void sos(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Radio, { className: "size-4" }), "SOS · 112"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "secondary",
					onClick: () => setPhase("results"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(OctagonX, { className: "size-4" }), "End walk"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mb-2 flex items-center gap-1.5 text-xs font-medium text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Flag, { className: "size-3.5" }), "Mark a hazard here"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: Object.keys(HAZARD_LABEL).map((kind) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					onClick: () => mark(kind),
					className: "rounded-full bg-surface-2 px-3 py-1.5 text-xs text-muted shadow-[0_0_0_1px_rgba(241,238,232,0.08)] hover:text-fg",
					children: HAZARD_LABEL[kind]
				}, kind))
			})] })
		]
	});
}
function Switch({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch$1, {
		className: cn("peer inline-flex h-6 w-10 shrink-0 cursor-pointer items-center rounded-full bg-surface-2 shadow-[0_0_0_1px_rgba(241,238,232,0.12)] transition-colors data-[state=checked]:bg-primary", className),
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SwitchThumb, { className: "pointer-events-none block size-5 translate-x-0.5 rounded-full bg-fg transition-transform data-[state=checked]:translate-x-[18px] data-[state=checked]:bg-primary-fg" })
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var searchPlaces = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("22dd64c431f956509af6c52f78efe2657ba2fec4a05476d6a2265baf114dc3cc"));
var reverseGeocode = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("9adbf68a15d15b1c3afe18f38f6440b0816972ca3405db633a16ff37230a28af"));
var planSafeRoute = createServerFn({ method: "POST" }).validator((input) => input).handler(createSsrRpc("3bd061db8a0a57ed781101163938496f0440fce73682086d418f6b4f49681910"));
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("flex h-11 w-full rounded-lg bg-surface-2 px-3 text-sm text-fg shadow-[0_0_0_1px_rgba(241,238,232,0.08)] placeholder:text-faint focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/60 disabled:cursor-not-allowed disabled:opacity-50", className),
		...props
	});
}
function PlaceSearch({ label, value, placeholder, bias, onSelect, onQueryChange }) {
	const id = (0, import_react.useId)();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [hits, setHits] = (0, import_react.useState)([]);
	const [loading, setLoading] = (0, import_react.useState)(false);
	const boxRef = (0, import_react.useRef)(null);
	(0, import_react.useEffect)(() => {
		const q = value.trim();
		if (q.length < 2) {
			setHits([]);
			return;
		}
		let cancelled = false;
		const t = window.setTimeout(() => {
			setLoading(true);
			searchPlaces({ data: {
				q,
				lat: bias?.lat,
				lng: bias?.lng
			} }).then((res) => {
				if (!cancelled) setHits(res);
			}).catch(() => {
				if (!cancelled) setHits([]);
			}).finally(() => {
				if (!cancelled) setLoading(false);
			});
		}, 280);
		return () => {
			cancelled = true;
			window.clearTimeout(t);
		};
	}, [
		value,
		bias?.lat,
		bias?.lng
	]);
	(0, import_react.useEffect)(() => {
		function onDoc(e) {
			if (!boxRef.current?.contains(e.target)) setOpen(false);
		}
		document.addEventListener("mousedown", onDoc);
		return () => document.removeEventListener("mousedown", onDoc);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		ref: boxRef,
		className: "relative",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				htmlFor: id,
				className: "mb-1.5 block text-xs font-medium text-muted",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "relative",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Search, { className: "pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					id,
					value,
					placeholder,
					autoComplete: "off",
					className: "pl-9",
					onChange: (e) => {
						onQueryChange(e.target.value);
						setOpen(true);
					},
					onFocus: () => setOpen(true)
				})]
			}),
			open && (hits.length > 0 || loading) && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
				className: "absolute z-30 mt-1 max-h-56 w-full overflow-auto rounded-xl bg-surface p-1 shadow-[0_0_0_1px_rgba(241,238,232,0.1),0_16px_40px_rgba(0,0,0,0.45)]",
				children: [loading && hits.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
					className: "px-3 py-2 text-xs text-muted",
					children: "Searching OpenStreetMap…"
				}), hits.map((hit) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: cn("flex w-full items-start gap-2 rounded-lg px-3 py-2 text-left hover:bg-surface-2"),
					onClick: () => {
						onSelect(hit);
						setOpen(false);
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPin, { className: "mt-0.5 size-4 shrink-0 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "min-w-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-sm text-fg",
							children: hit.name
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "block truncate text-xs text-muted",
							children: hit.label
						})]
					})]
				}) }, hit.id))]
			})
		]
	});
}
var SAMPLE_WALKS = [
	{
		id: "chennai",
		city: "Chennai",
		title: "T. Nagar to Marina Beach",
		origin: {
			id: "tnagar",
			name: "T. Nagar",
			label: "Pondy Bazaar, T. Nagar, Chennai",
			lat: 13.0418,
			lng: 80.2337
		},
		destination: {
			id: "marina",
			name: "Marina Beach",
			label: "Marina Beach, Chennai",
			lat: 13.05,
			lng: 80.2824
		}
	},
	{
		id: "delhi",
		city: "Delhi",
		title: "Connaught Place to India Gate",
		origin: {
			id: "cp",
			name: "Connaught Place",
			label: "Connaught Place, New Delhi",
			lat: 28.6304,
			lng: 77.2177
		},
		destination: {
			id: "ig",
			name: "India Gate",
			label: "India Gate, New Delhi",
			lat: 28.6129,
			lng: 77.2295
		}
	},
	{
		id: "london",
		city: "London",
		title: "Covent Garden to the British Museum",
		origin: {
			id: "cg",
			name: "Covent Garden",
			label: "Covent Garden, London",
			lat: 51.5117,
			lng: -.124
		},
		destination: {
			id: "bm",
			name: "British Museum",
			label: "British Museum, London",
			lat: 51.5194,
			lng: -.127
		}
	}
];
function useDeviceLocation(watch) {
	const setUser = useSafePath((s) => s.setUser);
	const setGps = useSafePath((s) => s.setGps);
	const setOrigin = useSafePath((s) => s.setOrigin);
	(0, import_react.useEffect)(() => {
		if (!watch) return;
		if (!navigator.geolocation) {
			setGps("denied");
			return;
		}
		setGps("asking");
		const onOk = (pos) => {
			const point = {
				lat: pos.coords.latitude,
				lng: pos.coords.longitude
			};
			setUser(point, pos.coords.heading && pos.coords.heading >= 0 ? pos.coords.heading : null);
			setGps("active");
			const current = useSafePath.getState().origin;
			if (!current) {
				setOrigin({
					id: "gps",
					name: "Current location",
					label: `${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`,
					lat: point.lat,
					lng: point.lng
				});
				reverseGeocode({ data: point }).then((r) => {
					if (useSafePath.getState().origin?.id !== "gps") return;
					setOrigin({
						id: "gps",
						name: "Current location",
						label: r.label,
						lat: point.lat,
						lng: point.lng
					});
				}).catch(() => {});
			} else if (current.id === "gps") setOrigin({
				...current,
				lat: point.lat,
				lng: point.lng
			});
		};
		const onErr = () => setGps("denied");
		navigator.geolocation.getCurrentPosition(onOk, onErr, {
			enableHighAccuracy: true,
			timeout: 12e3
		});
		const id = navigator.geolocation.watchPosition(onOk, onErr, {
			enableHighAccuracy: true,
			maximumAge: 4e3
		});
		return () => navigator.geolocation.clearWatch(id);
	}, [
		watch,
		setUser,
		setGps,
		setOrigin
	]);
}
async function requestLocationOnce() {
	if (!navigator.geolocation) return null;
	return new Promise((resolve) => {
		navigator.geolocation.getCurrentPosition((pos) => resolve({
			lat: pos.coords.latitude,
			lng: pos.coords.longitude
		}), () => resolve(null), {
			enableHighAccuracy: true,
			timeout: 12e3
		});
	});
}
function PathMark$1() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className: "size-8",
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M7 24c4-2 5-8 3-12 4 1 9 3 12 8 1-5 4-8 8-9",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.7",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "7",
				cy: "24",
				r: "2.1",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "30",
				cy: "11",
				r: "2.1",
				fill: "currentColor"
			})
		]
	});
}
function WelcomeGate() {
	const setPhase = useSafePath((s) => s.setPhase);
	const setOrigin = useSafePath((s) => s.setOrigin);
	useSafePath((s) => s.setDestination);
	const setUser = useSafePath((s) => s.setUser);
	const setGps = useSafePath((s) => s.setGps);
	async function useLocation() {
		setGps("asking");
		const point = await requestLocationOnce();
		if (!point) {
			setGps("denied");
			setPhase("plan");
			return;
		}
		setUser(point);
		setGps("active");
		setOrigin({
			id: "gps",
			name: "Current location",
			label: `${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`,
			lat: point.lat,
			lng: point.lng
		});
		setPhase("plan");
		try {
			const r = await reverseGeocode({ data: point });
			setOrigin({
				id: "gps",
				name: "Current location",
				label: r.label,
				lat: point.lat,
				lng: point.lng
			});
		} catch {}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative flex min-h-dvh flex-col bg-bg text-fg",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(216,222,230,0.08),transparent_55%)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex w-full max-w-lg flex-1 flex-col justify-between px-6 py-8 sm:py-12",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex items-center gap-3 text-fg",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PathMark$1, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl leading-tight tracking-tight",
						children: "SafePath"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Safer walks than the fastest route"
					})] })]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "py-10",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
							className: "font-display text-4xl leading-tight tracking-tight text-balance sm:text-5xl",
							children: ["Google Maps gets you there fastest.", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-muted",
								children: " SafePath gets you there safer."
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-md text-sm leading-relaxed text-muted text-pretty",
							children: "Shortcuts through unlit alleys, empty service roads, and quiet parks look efficient on a timer. They are a poor idea on the walk home. SafePath ranks OpenStreetMap walking paths by lighting, named streets, people, and help nearby."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
							className: "mt-8 grid gap-3",
							children: [
								{
									icon: Lamp,
									title: "Lighting over shortcuts",
									body: "Night walks prefer lit, named streets — not the alley that saves ninety seconds."
								},
								{
									icon: Shield,
									title: "Help on the map",
									body: "Police, hospitals, clinics, and pharmacies from OpenStreetMap sit on the route."
								},
								{
									icon: Moon,
									title: "A live companion",
									body: "Turn-by-turn, a safety briefing, and an SOS that shares where you are."
								}
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex gap-3 rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(241,238,232,0.06)]",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(item.icon, { className: "mt-0.5 size-4 shrink-0 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: item.title
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-muted",
									children: item.body
								})] })]
							}, item.title))
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "w-full",
							size: "lg",
							onClick: () => void useLocation(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapPinned, { className: "size-4" }), "Use my location"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							className: "w-full",
							size: "lg",
							variant: "secondary",
							onClick: () => setPhase("plan"),
							children: "Plan a walk instead"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "pt-1 text-center text-xs text-faint",
							children: "OpenStreetMap · OSRM · Overpass — no account, no tracking login"
						})
					]
				})
			]
		})]
	});
}
function SampleRow({ onPick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-2 overflow-x-auto pb-1",
		children: SAMPLE_WALKS.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			onClick: () => onPick(w.id),
			className: "shrink-0 rounded-full bg-surface-2 px-3 py-1.5 text-xs text-muted shadow-[0_0_0_1px_rgba(241,238,232,0.08)] hover:text-fg",
			children: w.city
		}, w.id))
	});
}
function PlannerPanel() {
	const origin = useSafePath((s) => s.origin);
	const destination = useSafePath((s) => s.destination);
	const night = useSafePath((s) => s.night);
	const planning = useSafePath((s) => s.planning);
	const error = useSafePath((s) => s.error);
	const hazards = useSafePath((s) => s.hazards);
	const gps = useSafePath((s) => s.gps);
	const setOrigin = useSafePath((s) => s.setOrigin);
	const setDestination = useSafePath((s) => s.setDestination);
	const setNight = useSafePath((s) => s.setNight);
	const setPlanning = useSafePath((s) => s.setPlanning);
	const setError = useSafePath((s) => s.setError);
	const applyPlan = useSafePath((s) => s.applyPlan);
	const setUser = useSafePath((s) => s.setUser);
	const setGps = useSafePath((s) => s.setGps);
	const [originQ, setOriginQ] = (0, import_react.useState)(origin?.label ?? "");
	const [destQ, setDestQ] = (0, import_react.useState)(destination?.label ?? "");
	(0, import_react.useEffect)(() => {
		if (origin?.label) setOriginQ(origin.label);
	}, [origin?.label]);
	(0, import_react.useEffect)(() => {
		if (destination?.label) setDestQ(destination.label);
	}, [destination?.label]);
	function fillOrigin(place) {
		setOrigin(place);
		setOriginQ(place.label);
	}
	function fillDest(place) {
		setDestination(place);
		setDestQ(place.label);
	}
	async function locateMe() {
		const point = await requestLocationOnce();
		if (!point) {
			setGps("denied");
			toast("Location permission was not granted. Search for a start instead.");
			return;
		}
		setGps("active");
		setUser(point);
		const place = {
			id: "gps",
			name: "Current location",
			label: `${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`,
			lat: point.lat,
			lng: point.lng
		};
		fillOrigin(place);
		try {
			const r = await reverseGeocode({ data: point });
			fillOrigin({
				...place,
				label: r.label
			});
		} catch {}
	}
	async function runPlan(from = origin, to = destination) {
		if (!from || !to) {
			setError("Choose a start and a destination.");
			return;
		}
		setPlanning(true);
		try {
			const plan = await planSafeRoute({ data: {
				origin: {
					lat: from.lat,
					lng: from.lng
				},
				destination: {
					lat: to.lat,
					lng: to.lng
				},
				originLabel: from.label,
				destLabel: to.label,
				night,
				hazards
			} });
			applyPlan(plan);
		} catch (err) {
			setError(err instanceof Error ? err.message : "Could not plan that walk.");
		}
	}
	function pickSample(id) {
		const w = SAMPLE_WALKS.find((s) => s.id === id);
		if (!w) return;
		fillOrigin(w.origin);
		fillDest(w.destination);
		runPlan(w.origin, w.destination);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-2xl tracking-tight",
				children: "Plan a safer walk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-muted",
				children: "We keep the time-saving shortcuts that Google Maps loves, then demote the ones that go dark or empty."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceSearch, {
				label: "From",
				value: originQ,
				placeholder: "Current location or an address",
				bias: origin,
				onSelect: fillOrigin,
				onQueryChange: (q) => {
					setOriginQ(q);
					if (origin && q !== origin.label) setOrigin(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlaceSearch, {
				label: "To",
				value: destQ,
				placeholder: "Where are you walking?",
				bias: origin,
				onSelect: fillDest,
				onQueryChange: (q) => {
					setDestQ(q);
					if (destination && q !== destination.label) setDestination(null);
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between rounded-xl bg-surface-2 px-3 py-2.5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoonStar, { className: "size-4 text-muted" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Night walk"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted",
						children: "Weights lighting and named streets more"
					})] })]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
					checked: night,
					onCheckedChange: setNight,
					"aria-label": "Night walk"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					variant: "secondary",
					className: "flex-1",
					onClick: () => void locateMe(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(LocateFixed, { className: "size-4" }), gps === "active" ? "Update location" : "Use location"]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					type: "button",
					className: "flex-[1.4]",
					disabled: planning,
					onClick: () => void runPlan(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigation, { className: "size-4" }), planning ? "Reading the streets…" : "Find safe path"]
				})]
			}),
			error && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-danger",
				children: error
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mb-2 text-xs font-medium text-muted",
				children: "Try a sample walk"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SampleRow, { onPick: pickSample })] })
		]
	});
}
function scoreTone(score) {
	if (score >= 75) return "safe";
	if (score >= 55) return "warn";
	return "danger";
}
function ResultsPanel() {
	const routes = useSafePath((s) => s.routes);
	const selectedId = useSafePath((s) => s.selectedId);
	const brief = useSafePath((s) => s.brief);
	const night = useSafePath((s) => s.night);
	const setSelected = useSafePath((s) => s.setSelected);
	const setPhase = useSafePath((s) => s.setPhase);
	const resetPlan = useSafePath((s) => s.resetPlan);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-2xl tracking-tight",
					children: "Choose how you walk"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-1 text-sm text-muted",
					children: [night ? "Night weights are on." : "Daytime weights.", " Safest is not always shortest."]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: resetPlan,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, { className: "size-4" }), "Edit"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-2",
				children: routes.map((route) => {
					const active = route.id === selectedId;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
						type: "button",
						onClick: () => setSelected(route.id),
						className: cn("rounded-2xl bg-surface-2 p-3 text-left transition-shadow", active ? "shadow-[0_0_0_1px_rgba(216,222,230,0.45)]" : "shadow-[0_0_0_1px_rgba(241,238,232,0.06)]"),
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center justify-between gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-sm font-medium",
									children: KIND_LABEL[route.kind]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Badge, {
									tone: scoreTone(route.score),
									children: ["Safety ", route.score]
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "mt-1 text-xs text-muted",
								children: [
									formatDuration(route.duration),
									" · ",
									formatDistance(route.distance)
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-2 text-sm text-muted",
								children: route.reasons[0]
							})
						]
					}, route.id);
				})
			}),
			brief && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(241,238,232,0.06)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 text-muted",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ShieldCheck, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-wider",
							children: "Safety briefing"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 font-display text-lg leading-snug tracking-tight",
						children: brief.headline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm leading-relaxed text-muted text-pretty",
						children: brief.summary
					}),
					brief.watchOuts.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-1.5 text-sm text-fg",
						children: brief.watchOuts.map((w) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "mt-1 size-1.5 shrink-0 rounded-full bg-warn" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: w })]
						}, w))
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "w-full",
				size: "lg",
				onClick: () => setPhase("navigate"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Footprints, { className: "size-4" }), "Start this walk"]
			})
		]
	});
}
function PathMark({ className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "0 0 32 32",
		className,
		"aria-hidden": "true",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				d: "M7 24c4-2 5-8 3-12 4 1 9 3 12 8 1-5 4-8 8-9",
				fill: "none",
				stroke: "currentColor",
				strokeWidth: "1.7",
				strokeLinecap: "round"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "7",
				cy: "24",
				r: "2.1",
				fill: "currentColor"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "30",
				cy: "11",
				r: "2.1",
				fill: "currentColor"
			})
		]
	});
}
function AppShell() {
	const phase = useSafePath((s) => s.phase);
	const origin = useSafePath((s) => s.origin);
	const destination = useSafePath((s) => s.destination);
	const user = useSafePath((s) => s.user);
	const routes = useSafePath((s) => s.routes);
	const selectedId = useSafePath((s) => s.selectedId);
	const amenities = useSafePath((s) => s.amenities);
	const hazards = useSafePath((s) => s.hazards);
	const follow = useSafePath((s) => s.follow);
	const setPhase = useSafePath((s) => s.setPhase);
	useDeviceLocation(phase === "plan" || phase === "results" || phase === "navigate");
	const [invalidate, setInvalidate] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		invalidate?.();
	}, [phase, invalidate]);
	if (phase === "welcome") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WelcomeGate, {});
	async function headerSos() {
		const pos = user ?? origin;
		if (!pos) {
			toast("Grant location or set a start first.");
			return;
		}
		const text = `I need help. My location: https://www.openstreetmap.org/?mlat=${pos.lat}&mlon=${pos.lng}#map=18/${pos.lat}/${pos.lng}`;
		try {
			await navigator.clipboard.writeText(text);
			toast("Location copied.");
		} catch {
			toast(text);
		}
		window.location.href = "tel:112";
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-dvh flex-col bg-bg text-fg",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
				theme: "dark",
				position: "top-center"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "z-20 flex items-center justify-between gap-3 border-b border-border px-4 py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
					type: "button",
					className: "flex items-center gap-2",
					onClick: () => setPhase("welcome"),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PathMark, { className: "size-6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-lg tracking-tight",
						children: "SafePath"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "danger",
					size: "sm",
					onClick: () => void headerSos(),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Siren, { className: "size-4" }), "SOS"]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid min-h-0 flex-1 lg:grid-cols-[minmax(20rem,26rem)_1fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
					className: "order-2 z-10 max-h-[52vh] overflow-y-auto border-t border-border bg-bg px-4 py-4 lg:order-1 lg:max-h-none lg:border-r lg:border-t-0 lg:px-5 lg:py-5",
					children: [
						phase === "plan" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PlannerPanel, {}),
						phase === "results" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ResultsPanel, {}),
						phase === "navigate" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavPanel, {})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "order-1 min-h-[42vh] lg:order-2 lg:min-h-0",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MapCanvas, {
						origin,
						destination,
						user,
						routes,
						selectedId,
						amenities,
						hazards,
						follow,
						onReady: (fn) => setInvalidate(() => fn)
					})
				})]
			})
		]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { Home as component };
