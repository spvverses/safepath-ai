//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DRnMVY7z.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-X6McSJjD.js", "/assets/rolldown-runtime-CbXtAM7H.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-X6McSJjD.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		css: ["/assets/routes-vh-t_kPv.css"],
		preloads: ["/assets/routes-W50FkL35.js"]
	}
} });
//#endregion
export { tsrStartManifest };
