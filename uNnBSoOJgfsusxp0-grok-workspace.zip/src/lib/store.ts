import { create } from "zustand";
import type {
  Amenity,
  Hazard,
  HazardKind,
  LatLng,
  PlaceHit,
  PlanResult,
  RouteKind,
  SafetyBrief,
  ScoredRoute,
} from "./types";
import { loadHazards, saveHazards } from "./hazards";

export type Phase = "welcome" | "plan" | "results" | "navigate";
export type GpsStatus = "idle" | "asking" | "active" | "denied";

type Store = {
  phase: Phase;
  gps: GpsStatus;
  night: boolean;
  origin: PlaceHit | null;
  destination: PlaceHit | null;
  user: LatLng | null;
  heading: number | null;
  routes: ScoredRoute[];
  selectedId: string | null;
  amenities: Amenity[];
  brief: SafetyBrief | null;
  hazards: Hazard[];
  planning: boolean;
  error: string | null;
  follow: boolean;
  setNight: (night: boolean) => void;
  setPhase: (phase: Phase) => void;
  setOrigin: (place: PlaceHit | null) => void;
  setDestination: (place: PlaceHit | null) => void;
  setUser: (point: LatLng | null, heading?: number | null) => void;
  setGps: (gps: GpsStatus) => void;
  setSelected: (id: string) => void;
  applyPlan: (plan: PlanResult) => void;
  setPlanning: (v: boolean) => void;
  setError: (msg: string | null) => void;
  addHazard: (kind: HazardKind, point: LatLng, note: string) => void;
  resetPlan: () => void;
  selectedRoute: () => ScoredRoute | null;
};

function isNightHour(): boolean {
  const h = new Date().getHours();
  return h >= 19 || h < 6;
}

export const useSafePath = create<Store>((set, get) => ({
  phase: "welcome",
  gps: "idle",
  night: isNightHour(),
  origin: null,
  destination: null,
  user: null,
  heading: null,
  routes: [],
  selectedId: null,
  amenities: [],
  brief: null,
  hazards: loadHazards(),
  planning: false,
  error: null,
  follow: false,
  setNight: (night) => set({ night }),
  setPhase: (phase) => set({ phase, follow: phase === "navigate" }),
  setOrigin: (origin) => set({ origin }),
  setDestination: (destination) => set({ destination }),
  setUser: (user, heading) =>
    set({
      user,
      heading: heading ?? get().heading,
    }),
  setGps: (gps) => set({ gps }),
  setSelected: (id) => set({ selectedId: id }),
  applyPlan: (plan) => {
    const preferred =
      plan.routes.find((r) => r.kind === "safest") ?? plan.routes[0] ?? null;
    set({
      routes: plan.routes,
      amenities: plan.amenities,
      brief: plan.brief,
      selectedId: preferred?.id ?? null,
      phase: "results",
      planning: false,
      error: null,
      night: plan.night,
      follow: false,
    });
  },
  setPlanning: (planning) => set({ planning, error: planning ? null : get().error }),
  setError: (error) => set({ error, planning: false }),
  addHazard: (kind, point, note) => {
    const hazard: Hazard = {
      id: crypto.randomUUID(),
      lat: point.lat,
      lng: point.lng,
      kind,
      note,
      at: Date.now(),
    };
    const hazards = [...get().hazards, hazard].slice(-80);
    saveHazards(hazards);
    set({ hazards });
  },
  resetPlan: () =>
    set({
      routes: [],
      selectedId: null,
      brief: null,
      amenities: [],
      phase: "plan",
      error: null,
    }),
  selectedRoute: () => {
    const { routes, selectedId } = get();
    return routes.find((r) => r.id === selectedId) ?? routes[0] ?? null;
  },
}));

export const KIND_LABEL: Record<RouteKind, string> = {
  safest: "Safest",
  balanced: "Balanced",
  fastest: "Fastest",
};

export const HAZARD_LABEL: Record<HazardKind, string> = {
  dark: "Poor lighting",
  isolated: "Isolated stretch",
  flood: "Flooding / water",
  other: "Other hazard",
};
