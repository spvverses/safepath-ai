import type { LatLng } from "./types";

const R = 6371000;

export function toRad(d: number): number {
  return (d * Math.PI) / 180;
}

export function haversineMeters(a: LatLng, b: LatLng): number {
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(s)));
}

export function destinationPoint(
  from: LatLng,
  bearingDeg: number,
  distanceM: number,
): LatLng {
  const br = toRad(bearingDeg);
  const ang = distanceM / R;
  const lat1 = toRad(from.lat);
  const lng1 = toRad(from.lng);
  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(ang) +
      Math.cos(lat1) * Math.sin(ang) * Math.cos(br),
  );
  const lng2 =
    lng1 +
    Math.atan2(
      Math.sin(br) * Math.sin(ang) * Math.cos(lat1),
      Math.cos(ang) - Math.sin(lat1) * Math.sin(lat2),
    );
  return { lat: (lat2 * 180) / Math.PI, lng: (lng2 * 180) / Math.PI };
}

export function bearingDegrees(a: LatLng, b: LatLng): number {
  const y =
    Math.sin(toRad(b.lng - a.lng)) * Math.cos(toRad(b.lat));
  const x =
    Math.cos(toRad(a.lat)) * Math.sin(toRad(b.lat)) -
    Math.sin(toRad(a.lat)) *
      Math.cos(toRad(b.lat)) *
      Math.cos(toRad(b.lng - a.lng));
  return ((Math.atan2(y, x) * 180) / Math.PI + 360) % 360;
}

export function sampleAlong(geometry: LatLng[], spacingM = 70): LatLng[] {
  if (geometry.length === 0) return [];
  const out: LatLng[] = [geometry[0]!];
  let acc = 0;
  for (let i = 1; i < geometry.length; i++) {
    const prev = geometry[i - 1]!;
    const cur = geometry[i]!;
    acc += haversineMeters(prev, cur);
    if (acc >= spacingM) {
      out.push(cur);
      acc = 0;
    }
  }
  const last = geometry[geometry.length - 1]!;
  const tail = out[out.length - 1]!;
  if (haversineMeters(tail, last) > 15) out.push(last);
  return out;
}

export function pathLength(geometry: LatLng[]): number {
  let n = 0;
  for (let i = 1; i < geometry.length; i++) {
    n += haversineMeters(geometry[i - 1]!, geometry[i]!);
  }
  return n;
}

export function nearestOnPath(
  point: LatLng,
  geometry: LatLng[],
): { dist: number; index: number; snapped: LatLng; along: number } {
  if (geometry.length === 0) {
    return { dist: Infinity, index: 0, snapped: point, along: 0 };
  }
  let bestDist = Infinity;
  let bestIndex = 0;
  let bestSnapped = geometry[0]!;
  let bestAlong = 0;
  let walked = 0;
  for (let i = 1; i < geometry.length; i++) {
    const a = geometry[i - 1]!;
    const b = geometry[i]!;
    const seg = haversineMeters(a, b);
    const snapped = closestOnSegment(point, a, b);
    const d = haversineMeters(point, snapped);
    if (d < bestDist) {
      bestDist = d;
      bestIndex = i - 1;
      bestSnapped = snapped;
      bestAlong = walked + haversineMeters(a, snapped);
    }
    walked += seg;
  }
  return { dist: bestDist, index: bestIndex, snapped: bestSnapped, along: bestAlong };
}

function closestOnSegment(p: LatLng, a: LatLng, b: LatLng): LatLng {
  const ax = a.lng;
  const ay = a.lat;
  const bx = b.lng;
  const by = b.lat;
  const dx = bx - ax;
  const dy = by - ay;
  const len2 = dx * dx + dy * dy;
  if (len2 === 0) return a;
  const t = Math.max(0, Math.min(1, ((p.lng - ax) * dx + (p.lat - ay) * dy) / len2));
  return { lat: ay + t * dy, lng: ax + t * dx };
}

export function remainingDistance(point: LatLng, geometry: LatLng[]): number {
  const near = nearestOnPath(point, geometry);
  return Math.max(0, pathLength(geometry) - near.along);
}

export function bboxOf(points: LatLng[], padM = 180): {
  south: number;
  west: number;
  north: number;
  east: number;
} {
  let south = 90;
  let west = 180;
  let north = -90;
  let east = -180;
  for (const p of points) {
    south = Math.min(south, p.lat);
    north = Math.max(north, p.lat);
    west = Math.min(west, p.lng);
    east = Math.max(east, p.lng);
  }
  const padLat = padM / 111320;
  const midLat = (south + north) / 2;
  const padLng = padM / (111320 * Math.max(0.2, Math.cos(toRad(midLat))));
  return {
    south: south - padLat,
    west: west - padLng,
    north: north + padLat,
    east: east + padLng,
  };
}

export function routesSimilar(a: LatLng[], b: LatLng[], thresholdM = 55): boolean {
  const sa = sampleAlong(a, 90);
  const sb = sampleAlong(b, 90);
  if (sa.length === 0 || sb.length === 0) return false;
  const maxMin = (from: LatLng[], to: LatLng[]) => {
    let worst = 0;
    for (const p of from) {
      let best = Infinity;
      for (const q of to) best = Math.min(best, haversineMeters(p, q));
      worst = Math.max(worst, best);
    }
    return worst;
  };
  return Math.max(maxMin(sa, sb), maxMin(sb, sa)) < thresholdM;
}
