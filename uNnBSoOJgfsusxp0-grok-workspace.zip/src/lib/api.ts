import { createServerFn } from "@tanstack/react-start";
import type { Hazard, LatLng, PlaceHit, PlanResult } from "./types";

export const searchPlaces = createServerFn({ method: "POST" })
  .validator((input: { q: string; lat?: number; lng?: number }) => input)
  .handler(async ({ data }): Promise<PlaceHit[]> => {
    const q = data.q.trim();
    if (q.length < 2) return [];
    const { searchPhoton } = await import("./plan.server");
    const bias =
      data.lat != null && data.lng != null ? { lat: data.lat, lng: data.lng } : undefined;
    return searchPhoton(q, bias);
  });

export const reverseGeocode = createServerFn({ method: "POST" })
  .validator((input: LatLng) => input)
  .handler(async ({ data }): Promise<{ label: string }> => {
    const { reversePlace } = await import("./plan.server");
    const label = await reversePlace(data);
    return { label };
  });

export const planSafeRoute = createServerFn({ method: "POST" })
  .validator(
    (input: {
      origin: LatLng;
      destination: LatLng;
      originLabel: string;
      destLabel: string;
      night: boolean;
      hazards: Hazard[];
    }) => input,
  )
  .handler(async ({ data }): Promise<PlanResult> => {
    const { planSafeWalk } = await import("./plan.server");
    return planSafeWalk(data);
  });
