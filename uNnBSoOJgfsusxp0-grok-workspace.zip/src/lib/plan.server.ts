import { bboxOf, destinationPoint, haversineMeters, routesSimilar } from "./geo";
import { assignKinds, fallbackBrief, scoreCandidate } from "./safety";
import type {
  Amenity,
  AmenityKind,
  Hazard,
  LatLng,
  PlanResult,
  RouteStep,
  SafetyBrief,
} from "./types";

const USER_AGENT = "SafePath/1.0 (open-source pedestrian safety routing)";

type OsrmRoute = {
  distance: number;
  duration: number;
  geometry?: { coordinates: [number, number][] };
  legs?: Array<{
    steps?: Array<{
      distance: number;
      duration: number;
      name?: string;
      maneuver?: {
        type?: string;
        modifier?: string;
        location?: [number, number];
      };
    }>;
  }>;
};

function instructionFor(step: NonNullable<NonNullable<OsrmRoute["legs"]>[0]["steps"]>[0]): string {
  const type = step.maneuver?.type ?? "continue";
  const modifier = step.maneuver?.modifier;
  const name = step.name && step.name !== "-" ? step.name : "";
  const onto = name ? ` onto ${name}` : "";
  if (type === "depart") return name ? `Start on ${name}` : "Start walking on the highlighted path";
  if (type === "arrive") return "You have arrived";
  if (type === "roundabout" || type === "rotary") return `Enter the roundabout${onto}`;
  if (type === "turn" || type === "end of road" || type === "fork" || type === "off ramp") {
    const dir = modifier ? modifier.replace(/_/g, " ") : "ahead";
    return `Turn ${dir}${onto}`;
  }
  if (type === "new name" || type === "continue") {
    return name ? `Continue on ${name}` : "Continue straight";
  }
  return name ? `Continue on ${name}` : "Continue";
}

function stepsFrom(route: OsrmRoute): RouteStep[] {
  const raw = route.legs?.flatMap((l) => l.steps ?? []) ?? [];
  return raw.map((s) => {
    const loc = s.maneuver?.location;
    return {
      instruction: instructionFor(s),
      distance: s.distance,
      duration: s.duration,
      name: s.name && s.name !== "-" ? s.name : "",
      location: loc ? { lat: loc[1], lng: loc[0] } : { lat: 0, lng: 0 },
    };
  });
}

function geometryFrom(route: OsrmRoute): LatLng[] {
  return (route.geometry?.coordinates ?? []).map(([lng, lat]) => ({ lat, lng }));
}

async function fetchJson(url: string, init: RequestInit | undefined, ms: number): Promise<unknown> {
  const res = await fetch(url, {
    ...init,
    signal: AbortSignal.timeout(ms),
    headers: {
      Accept: "application/json",
      "User-Agent": USER_AGENT,
      ...(init?.headers ?? {}),
    },
  });
  if (!res.ok) throw new Error(`Request failed (${res.status})`);
  return res.json();
}

async function osrmRoute(points: LatLng[], alternatives = false): Promise<OsrmRoute[]> {
  const path = points.map((p) => `${p.lng},${p.lat}`).join(";");
  const params = new URLSearchParams({
    overview: "full",
    geometries: "geojson",
    steps: "true",
    alternatives: alternatives ? "true" : "false",
  });
  const url = `https://router.project-osrm.org/route/v1/foot/${path}?${params.toString()}`;
  const json = (await fetchJson(url, undefined, 12000)) as {
    code?: string;
    routes?: OsrmRoute[];
  };
  if (json.code && json.code !== "Ok") return [];
  return json.routes ?? [];
}

function amenityKind(tags: Record<string, string | undefined>): AmenityKind | null {
  const amenity = tags.amenity;
  const shop = tags.shop;
  const highway = tags.highway;
  if (highway === "street_lamp") return "lamp";
  if (amenity === "police") return "police";
  if (amenity === "hospital") return "hospital";
  if (amenity === "clinic") return "clinic";
  if (amenity === "pharmacy") return "pharmacy";
  if (amenity === "fire_station") return "fire";
  if (shop === "convenience" || shop === "supermarket" || amenity === "marketplace") return "shop";
  return null;
}

async function fetchSafetyLayer(points: LatLng[]): Promise<{ amenities: Amenity[]; lamps: LatLng[] }> {
  const box = bboxOf(points, 220);
  const bbox = `${box.south},${box.west},${box.north},${box.east}`;
  const query = `[out:json][timeout:12];
(
  node["highway"="street_lamp"](${bbox});
  node["amenity"="police"](${bbox});
  node["amenity"="hospital"](${bbox});
  node["amenity"="clinic"](${bbox});
  node["amenity"="pharmacy"](${bbox});
  node["amenity"="fire_station"](${bbox});
  node["shop"="convenience"](${bbox});
  node["shop"="supermarket"](${bbox});
);
out center 250;`;

  type OverpassElement = {
    id: number;
    lat?: number;
    lon?: number;
    center?: { lat: number; lon: number };
    tags?: Record<string, string>;
  };
  type OverpassResponse = { elements?: OverpassElement[] };

  const endpoints = [
    "https://overpass-api.de/api/interpreter",
    "https://overpass.kumi.systems/api/interpreter",
  ];
  let json: OverpassResponse | null = null;
  for (const endpoint of endpoints) {
    try {
      json = (await fetchJson(
        endpoint,
        {
          method: "POST",
          headers: { "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8" },
          body: new URLSearchParams({ data: query }),
        },
        14000,
      )) as OverpassResponse;
      break;
    } catch {
      json = null;
    }
  }
  const amenities: Amenity[] = [];
  const lamps: LatLng[] = [];
  for (const el of json?.elements ?? []) {
    const lat = el.lat ?? el.center?.lat;
    const lng = el.lon ?? el.center?.lon;
    if (lat == null || lng == null) continue;
    const kind = amenityKind(el.tags ?? {});
    if (!kind) continue;
    if (kind === "lamp") {
      lamps.push({ lat, lng });
      continue;
    }
    amenities.push({
      id: String(el.id),
      kind,
      name: el.tags?.name ?? kind,
      lat,
      lng,
    });
  }
  return { amenities: amenities.slice(0, 80), lamps: lamps.slice(0, 400) };
}

function pickVia(origin: LatLng, dest: LatLng, amenities: Amenity[]): LatLng | null {
  const direct = haversineMeters(origin, dest);
  if (direct < 250) return null;
  const mid: LatLng = {
    lat: (origin.lat + dest.lat) / 2,
    lng: (origin.lng + dest.lng) / 2,
  };
  const rank: Record<Amenity["kind"], number> = {
    police: 5,
    hospital: 4,
    fire: 4,
    pharmacy: 3,
    clinic: 3,
    shop: 2,
    lamp: 0,
  };
  let best: { a: Amenity; score: number } | null = null;
  for (const a of amenities) {
    const detour = haversineMeters(origin, a) + haversineMeters(a, dest);
    if (detour > direct * 1.38) continue;
    if (haversineMeters(a, origin) < 80 || haversineMeters(a, dest) < 80) continue;
    const towardMid = 1 / (1 + haversineMeters(a, mid) / 400);
    const score = (rank[a.kind] ?? 0) * 12 + towardMid * 20;
    if (!best || score > best.score) best = { a, score };
  }
  if (best) return { lat: best.a.lat, lng: best.a.lng };
  const br = Math.atan2(dest.lng - origin.lng, dest.lat - origin.lat) * (180 / Math.PI);
  return destinationPoint(mid, br + 90, Math.min(280, direct * 0.12));
}

async function briefWithGrok(input: {
  originLabel: string;
  destLabel: string;
  night: boolean;
  route: ReturnType<typeof assignKinds>[0];
}): Promise<SafetyBrief> {
  const fallback = fallbackBrief(input.route, input.night);
  const apiKey = process.env.XAI_API_KEY;
  if (!apiKey) return fallback;

  const prompt = `You are SafePath, a pedestrian-safety advisor. Google Maps optimizes for time; we optimize for a safer walk.

Walk: ${input.originLabel} → ${input.destLabel}
Time: ${input.night ? "night / low light" : "daytime"}
Distance: ${Math.round(input.route.distance)} m, duration ${Math.round(input.route.duration / 60)} min
Safety score: ${input.route.score}/100
Lighting ${input.route.breakdown.lighting}, populated ${input.route.breakdown.populated}, emergency access ${input.route.breakdown.emergency}, named-street quality ${input.route.breakdown.isolation}
Notes: ${input.route.reasons.join("; ")}

Reply with compact JSON only:
{"headline":"...","summary":"2 sentences","watchOuts":["..."],"tips":["..."]}
No markdown. Be specific and calm. Do not invent street names that were not provided.`;

  try {
    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        temperature: 0.3,
        max_tokens: 420,
        messages: [{ role: "user", content: prompt }],
      }),
      signal: AbortSignal.timeout(18000),
    });
    if (!res.ok) return fallback;
    const body = (await res.json()) as { choices?: Array<{ message?: { content?: string } }> };
    let text = body.choices?.[0]?.message?.content?.trim() ?? "";
    const fence = text.match(/\{[\s\S]*\}/);
    if (fence) text = fence[0];
    const parsed = JSON.parse(text) as SafetyBrief;
    if (!parsed.headline || !parsed.summary) return fallback;
    return {
      headline: String(parsed.headline).slice(0, 140),
      summary: String(parsed.summary).slice(0, 420),
      watchOuts: (parsed.watchOuts ?? []).map(String).slice(0, 4),
      tips: (parsed.tips ?? []).map(String).slice(0, 4),
    };
  } catch {
    return fallback;
  }
}

export async function planSafeWalk(input: {
  origin: LatLng;
  destination: LatLng;
  originLabel: string;
  destLabel: string;
  night: boolean;
  hazards: Hazard[];
}): Promise<PlanResult> {
  const direct = haversineMeters(input.origin, input.destination);
  if (direct < 40) {
    throw new Error("Origin and destination are too close to plan a walk.");
  }
  if (direct > 25000) {
    throw new Error("That's farther than a reasonable walk. Pick a closer destination.");
  }

  const primary = await osrmRoute([input.origin, input.destination], true);
  if (primary.length === 0) {
    throw new Error("No walking path found between those places. Try a nearby street or landmark.");
  }

  const allPoints = [
    input.origin,
    input.destination,
    ...primary.flatMap((r) => geometryFrom(r)),
  ];
  const layer = await fetchSafetyLayer(allPoints);

  const via = pickVia(input.origin, input.destination, layer.amenities);
  let viaRoutes: OsrmRoute[] = [];
  if (via) {
    try {
      viaRoutes = await osrmRoute([input.origin, via, input.destination], false);
    } catch {
      viaRoutes = [];
    }
  }

  const merged: OsrmRoute[] = [];
  for (const r of [...primary, ...viaRoutes]) {
    const geo = geometryFrom(r);
    if (geo.length < 2) continue;
    if (merged.some((m) => routesSimilar(geometryFrom(m), geo))) continue;
    merged.push(r);
  }

  const scored = merged.map((r) =>
    scoreCandidate({
      geometry: geometryFrom(r),
      steps: stepsFrom(r),
      distance: r.distance,
      duration: r.duration,
      amenities: layer.amenities,
      lamps: layer.lamps,
      hazards: input.hazards,
      night: input.night,
    }),
  );

  const routes = assignKinds(scored);
  if (routes.length === 0) {
    throw new Error("Couldn't score a walking path. Try again in a moment.");
  }

  const preferred = routes.find((r) => r.kind === "safest") ?? routes[0]!;
  const brief = await briefWithGrok({
    originLabel: input.originLabel,
    destLabel: input.destLabel,
    night: input.night,
    route: preferred,
  });

  const mapAmenities = layer.amenities.filter((a) => a.kind !== "lamp").slice(0, 48);
  return { routes, amenities: mapAmenities, brief, night: input.night };
}

export async function searchPhoton(q: string, bias?: LatLng): Promise<
  Array<{ id: string; name: string; label: string; lat: number; lng: number }>
> {
  const params = new URLSearchParams({ q: q.trim(), limit: "6" });
  if (bias) {
    params.set("lat", String(bias.lat));
    params.set("lon", String(bias.lng));
  }
  try {
    const json = (await fetchJson(
      `https://photon.komoot.io/api/?${params.toString()}`,
      undefined,
      8000,
    )) as {
      features?: Array<{
        geometry?: { coordinates?: [number, number] };
        properties?: {
          osm_id?: number;
          name?: string;
          street?: string;
          city?: string;
          state?: string;
          country?: string;
          housenumber?: string;
        };
      }>;
    };
    return (json.features ?? [])
      .map((f) => {
        const c = f.geometry?.coordinates;
        if (!c) return null;
        const p = f.properties ?? {};
        const name = p.name || p.street || "Place";
        const bits = [p.housenumber, p.street, p.city, p.state].filter(Boolean);
        return {
          id: String(p.osm_id ?? `${c[1]},${c[0]}`),
          name,
          label: bits.length ? `${name} — ${bits.join(", ")}` : name,
          lat: c[1],
          lng: c[0],
        };
      })
      .filter((x): x is NonNullable<typeof x> => x != null);
  } catch {
    return searchNominatim(q);
  }
}

async function searchNominatim(q: string): Promise<
  Array<{ id: string; name: string; label: string; lat: number; lng: number }>
> {
  const params = new URLSearchParams({
    q: q.trim(),
    format: "jsonv2",
    limit: "6",
    addressdetails: "0",
  });
  const json = (await fetchJson(
    `https://nominatim.openstreetmap.org/search?${params.toString()}`,
    undefined,
    9000,
  )) as Array<{ place_id: number; display_name: string; lat: string; lon: string }>;
  return (json ?? []).map((row) => ({
    id: String(row.place_id),
    name: row.display_name.split(",")[0] ?? row.display_name,
    label: row.display_name,
    lat: Number(row.lat),
    lng: Number(row.lon),
  }));
}

export async function reversePlace(point: LatLng): Promise<string> {
  try {
    const params = new URLSearchParams({
      lat: String(point.lat),
      lon: String(point.lng),
      format: "jsonv2",
    });
    const json = (await fetchJson(
      `https://nominatim.openstreetmap.org/reverse?${params.toString()}`,
      undefined,
      8000,
    )) as { display_name?: string; name?: string; address?: Record<string, string> };
    const a = json.address ?? {};
    const short = [a.road, a.neighbourhood || a.suburb, a.city || a.town || a.village]
      .filter(Boolean)
      .join(", ");
    return short || json.name || json.display_name || `${point.lat.toFixed(4)}, ${point.lng.toFixed(4)}`;
  } catch {
    return `${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`;
  }
}
