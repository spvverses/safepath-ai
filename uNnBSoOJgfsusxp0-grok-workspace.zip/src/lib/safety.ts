import { haversineMeters, sampleAlong } from "./geo";
import type {
  Amenity,
  Hazard,
  LatLng,
  RouteStep,
  SafetyBreakdown,
  ScoredRoute,
} from "./types";

function clamp(n: number, min = 0, max = 100): number {
  return Math.max(min, Math.min(max, n));
}

function nearestAmenity(
  point: LatLng,
  amenities: Amenity[],
  kinds: Amenity["kind"][],
): number {
  let best = Infinity;
  for (const a of amenities) {
    if (!kinds.includes(a.kind)) continue;
    best = Math.min(best, haversineMeters(point, a));
  }
  return best;
}

function countWithin(point: LatLng, points: LatLng[], radius: number): number {
  let n = 0;
  for (const p of points) {
    if (haversineMeters(point, p) <= radius) n += 1;
  }
  return n;
}

function isolationFromSteps(steps: RouteStep[]): number {
  if (steps.length === 0) return 55;
  const unnamed = steps.filter((s) => !s.name || s.name === "-").length;
  const quiet = steps.filter((s) =>
    /alley|path|track|steps|footway|service/i.test(s.name + " " + s.instruction),
  ).length;
  const namedRatio = 1 - unnamed / steps.length;
  const quietRatio = quiet / steps.length;
  return clamp(namedRatio * 100 - quietRatio * 28);
}

export function scoreCandidate(input: {
  geometry: LatLng[];
  steps: RouteStep[];
  distance: number;
  duration: number;
  amenities: Amenity[];
  lamps: LatLng[];
  hazards: Hazard[];
  night: boolean;
}): Omit<ScoredRoute, "id" | "kind"> {
  const samples = sampleAlong(input.geometry, 75);
  const lampPts = input.lamps;
  const peoplePts = input.amenities
    .filter((a) => a.kind === "shop" || a.kind === "pharmacy" || a.kind === "clinic")
    .map((a) => ({ lat: a.lat, lng: a.lng }));
  const helpKinds: Amenity["kind"][] = ["police", "hospital", "clinic", "fire", "pharmacy"];

  let litHits = 0;
  let peopleHits = 0;
  let helpAcc = 0;
  for (const p of samples) {
    if (lampPts.length === 0) {
      litHits += 0;
    } else if (countWithin(p, lampPts, 45) > 0) {
      litHits += 1;
    }
    if (countWithin(p, peoplePts, 90) > 0) peopleHits += 1;
    const help = nearestAmenity(p, input.amenities, helpKinds);
    helpAcc += help === Infinity ? 0 : clamp(100 - (help / 9), 0, 100);
  }

  const n = Math.max(1, samples.length);
  const lampCoverage = lampPts.length >= 6 ? (litHits / n) * 100 : null;
  const namedStreet = isolationFromSteps(input.steps);
  const lighting =
    lampCoverage == null ? namedStreet : lampCoverage * 0.7 + namedStreet * 0.3;

  const hasPeopleData = peoplePts.length > 0;
  const populated = hasPeopleData ? (peopleHits / n) * 100 : namedStreet * 0.85;

  const hasHelp = input.amenities.some((a) => helpKinds.includes(a.kind));
  const emergency = hasHelp ? helpAcc / n : 52;
  const isolation = namedStreet;

  let hazardPenalty = 0;
  const reasons: string[] = [];
  for (const h of input.hazards) {
    for (const p of samples) {
      if (haversineMeters(p, h) < 50) {
        hazardPenalty += 12;
        break;
      }
    }
  }

  const breakdown: SafetyBreakdown = {
    lighting: Math.round(clamp(lighting)),
    populated: Math.round(clamp(populated)),
    emergency: Math.round(clamp(emergency)),
    isolation: Math.round(clamp(isolation)),
  };

  const wLight = input.night ? 0.4 : 0.2;
  const wPop = input.night ? 0.22 : 0.24;
  const wEm = 0.2;
  const wIso = input.night ? 0.18 : 0.36;
  const raw =
    breakdown.lighting * wLight +
    breakdown.populated * wPop +
    breakdown.emergency * wEm +
    breakdown.isolation * wIso -
    Math.min(36, hazardPenalty);
  const score = Math.round(clamp(raw));

  if (breakdown.lighting >= 70) reasons.push("Better lighting along this walk");
  else if (input.night && breakdown.lighting < 45) reasons.push("Dim stretches after dark — stay on named streets");
  if (breakdown.populated >= 65) reasons.push("Passes shops and active frontage");
  else if (breakdown.populated < 40) reasons.push("Quieter blocks with fewer people around");
  if (breakdown.emergency >= 55) reasons.push("Help is relatively close (clinic, pharmacy, or police)");
  if (breakdown.isolation >= 70) reasons.push("Prefers named roads over alleys and paths");
  else if (breakdown.isolation < 45) reasons.push("Includes quieter paths that Google Maps often treats as shortcuts");
  if (hazardPenalty > 0) reasons.push("A reported hazard sits near this path");
  if (reasons.length === 0) reasons.push("OpenStreetMap walking path with a balanced safety score");

  return {
    distance: input.distance,
    duration: input.duration,
    geometry: input.geometry,
    steps: input.steps,
    score,
    breakdown,
    reasons: reasons.slice(0, 3),
  };
}

export function assignKinds(routes: Omit<ScoredRoute, "id" | "kind">[]): ScoredRoute[] {
  if (routes.length === 0) return [];
  const fastest = routes.reduce((a, b) => (a.duration <= b.duration ? a : b));
  const safest = routes.reduce((a, b) => (a.score >= b.score ? a : b));
  const maxDur = Math.max(...routes.map((r) => r.duration), 1);
  const minDur = Math.min(...routes.map((r) => r.duration), 1);
  const span = Math.max(1, maxDur - minDur);
  const balanced = routes.reduce((best, r) => {
    const timeNorm = 100 - ((r.duration - minDur) / span) * 100;
    const mix = r.score * 0.58 + timeNorm * 0.42;
    const bestTime = 100 - ((best.duration - minDur) / span) * 100;
    const bestMix = best.score * 0.58 + bestTime * 0.42;
    return mix > bestMix ? r : best;
  });

  const picked: { kind: ScoredRoute["kind"]; route: Omit<ScoredRoute, "id" | "kind"> }[] = [
    { kind: "safest", route: safest },
  ];
  if (balanced !== safest) picked.push({ kind: "balanced", route: balanced });
  if (fastest !== safest && fastest !== balanced) picked.push({ kind: "fastest", route: fastest });
  else if (picked.length === 1 && routes.length > 1) {
    const other = routes.find((r) => r !== safest);
    if (other) picked.push({ kind: "fastest", route: other });
  }

  return picked.map((p, i) => ({
    ...p.route,
    kind: p.kind,
    id: `${p.kind}-${i}`,
  }));
}

export function fallbackBrief(route: ScoredRoute, night: boolean): {
  headline: string;
  summary: string;
  watchOuts: string[];
  tips: string[];
} {
  const headline =
    route.score >= 78
      ? "A well-supported walking route"
      : route.score >= 58
        ? night
          ? "Usable at night, with a few quieter stretches"
          : "A reasonable walk with a few quiet blocks"
        : "Take extra care — this is the best path we could score";
  const summary = route.reasons.join(". ") + ".";
  const watchOuts = [
    ...(route.breakdown.lighting < 50 ? ["Lighting is uneven — keep to the wider named streets."] : []),
    ...(route.breakdown.isolation < 50 ? ["Avoid slipping into alleys even if they look shorter."] : []),
    ...(night ? ["After dark, prefer blocks with shops still open."] : []),
  ].slice(0, 3);
  const tips = [
    "Share your live location with someone you trust before you start.",
    "If a street feels wrong, leave the shortcut and return to the last named road.",
    "Pharmacies, hospitals, and police posts are marked on the map when OpenStreetMap has them.",
  ];
  return { headline, summary, watchOuts: watchOuts.length ? watchOuts : ["Stay on the highlighted path."], tips };
}
