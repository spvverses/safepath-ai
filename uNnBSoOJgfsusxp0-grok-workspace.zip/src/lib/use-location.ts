import { useEffect } from "react";
import { reverseGeocode } from "./api";
import { useSafePath } from "./store";

export function useDeviceLocation(watch: boolean) {
  const setUser = useSafePath((s) => s.setUser);
  const setGps = useSafePath((s) => s.setGps);
  const setOrigin = useSafePath((s) => s.setOrigin);

  useEffect(() => {
    if (!watch) return;
    if (!navigator.geolocation) {
      setGps("denied");
      return;
    }
    setGps("asking");
    const onOk = (pos: GeolocationPosition) => {
      const point = { lat: pos.coords.latitude, lng: pos.coords.longitude };
      setUser(point, pos.coords.heading && pos.coords.heading >= 0 ? pos.coords.heading : null);
      setGps("active");
      const current = useSafePath.getState().origin;
      if (!current) {
        setOrigin({
          id: "gps",
          name: "Current location",
          label: `${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`,
          lat: point.lat,
          lng: point.lng,
        });
        void reverseGeocode({ data: point })
          .then((r) => {
            const still = useSafePath.getState().origin;
            if (still?.id !== "gps") return;
            setOrigin({
              id: "gps",
              name: "Current location",
              label: r.label,
              lat: point.lat,
              lng: point.lng,
            });
          })
          .catch(() => {});
      } else if (current.id === "gps") {
        setOrigin({
          ...current,
          lat: point.lat,
          lng: point.lng,
        });
      }
    };
    const onErr = () => setGps("denied");
    navigator.geolocation.getCurrentPosition(onOk, onErr, {
      enableHighAccuracy: true,
      timeout: 12000,
    });
    const id = navigator.geolocation.watchPosition(onOk, onErr, {
      enableHighAccuracy: true,
      maximumAge: 4000,
    });
    return () => navigator.geolocation.clearWatch(id);
  }, [watch, setUser, setGps, setOrigin]);
}

export async function requestLocationOnce(): Promise<{
  lat: number;
  lng: number;
} | null> {
  if (!navigator.geolocation) return null;
  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (pos) => resolve({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => resolve(null),
      { enableHighAccuracy: true, timeout: 12000 },
    );
  });
}
