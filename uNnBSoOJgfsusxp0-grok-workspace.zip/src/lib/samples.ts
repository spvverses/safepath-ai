import type { SampleWalk } from "./types";

export const SAMPLE_WALKS: SampleWalk[] = [
  {
    id: "chennai",
    city: "Chennai",
    title: "T. Nagar to Marina Beach",
    origin: {
      id: "tnagar",
      name: "T. Nagar",
      label: "Pondy Bazaar, T. Nagar, Chennai",
      lat: 13.0418,
      lng: 80.2337,
    },
    destination: {
      id: "marina",
      name: "Marina Beach",
      label: "Marina Beach, Chennai",
      lat: 13.05,
      lng: 80.2824,
    },
  },
  {
    id: "delhi",
    city: "Delhi",
    title: "Connaught Place to India Gate",
    origin: {
      id: "cp",
      name: "Connaught Place",
      label: "Connaught Place, New Delhi",
      lat: 28.6304,
      lng: 77.2177,
    },
    destination: {
      id: "ig",
      name: "India Gate",
      label: "India Gate, New Delhi",
      lat: 28.6129,
      lng: 77.2295,
    },
  },
  {
    id: "london",
    city: "London",
    title: "Covent Garden to the British Museum",
    origin: {
      id: "cg",
      name: "Covent Garden",
      label: "Covent Garden, London",
      lat: 51.5117,
      lng: -0.124,
    },
    destination: {
      id: "bm",
      name: "British Museum",
      label: "British Museum, London",
      lat: 51.5194,
      lng: -0.127,
    },
  },
];
