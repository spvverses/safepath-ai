import { useEffect, useState } from "react";
import { LocateFixed, MoonStar, Navigation } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { PlaceSearch } from "@/components/place-search";
import { SampleRow } from "@/components/welcome-gate";
import { planSafeRoute, reverseGeocode } from "@/lib/api";
import { SAMPLE_WALKS } from "@/lib/samples";
import { useSafePath } from "@/lib/store";
import { requestLocationOnce } from "@/lib/use-location";
import type { PlaceHit } from "@/lib/types";

export function PlannerPanel() {
  const origin = useSafePath((s) => s.origin);
  const destination = useSafePath((s) => s.destination);
  const night = useSafePath((s) => s.night);
  const planning = useSafePath((s) => s.planning);
  const error = useSafePath((s) => s.error);
  const hazards = useSafePath((s) => s.hazards);
  const gps = useSafePath((s) => s.gps);
  const setOrigin = useSafePath((s) => s.setOrigin);
  const setDestination = useSafePath((s) => s.setDestination);
  const setNight = useSafePath((s) => s.setNight);
  const setPlanning = useSafePath((s) => s.setPlanning);
  const setError = useSafePath((s) => s.setError);
  const applyPlan = useSafePath((s) => s.applyPlan);
  const setUser = useSafePath((s) => s.setUser);
  const setGps = useSafePath((s) => s.setGps);

  const [originQ, setOriginQ] = useState(origin?.label ?? "");
  const [destQ, setDestQ] = useState(destination?.label ?? "");

  useEffect(() => {
    if (origin?.label) setOriginQ(origin.label);
  }, [origin?.label]);
  useEffect(() => {
    if (destination?.label) setDestQ(destination.label);
  }, [destination?.label]);

  function fillOrigin(place: PlaceHit) {
    setOrigin(place);
    setOriginQ(place.label);
  }
  function fillDest(place: PlaceHit) {
    setDestination(place);
    setDestQ(place.label);
  }

  async function locateMe() {
    const point = await requestLocationOnce();
    if (!point) {
      setGps("denied");
      toast("Location permission was not granted. Search for a start instead.");
      return;
    }
    setGps("active");
    setUser(point);
    const place: PlaceHit = {
      id: "gps",
      name: "Current location",
      label: `${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`,
      lat: point.lat,
      lng: point.lng,
    };
    fillOrigin(place);
    try {
      const r = await reverseGeocode({ data: point });
      fillOrigin({ ...place, label: r.label });
    } catch {
      /* keep coords */
    }
  }

  async function runPlan(from = origin, to = destination) {
    if (!from || !to) {
      setError("Choose a start and a destination.");
      return;
    }
    setPlanning(true);
    try {
      const plan = await planSafeRoute({
        data: {
          origin: { lat: from.lat, lng: from.lng },
          destination: { lat: to.lat, lng: to.lng },
          originLabel: from.label,
          destLabel: to.label,
          night,
          hazards,
        },
      });
      applyPlan(plan);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Could not plan that walk.");
    }
  }

  function pickSample(id: string) {
    const w = SAMPLE_WALKS.find((s) => s.id === id);
    if (!w) return;
    fillOrigin(w.origin);
    fillDest(w.destination);
    void runPlan(w.origin, w.destination);
  }

  return (
    <div className="space-y-4">
      <div>
        <p className="font-display text-2xl tracking-tight">Plan a safer walk</p>
        <p className="mt-1 text-sm text-muted">
          We keep the time-saving shortcuts that Google Maps loves, then demote the ones that go
          dark or empty.
        </p>
      </div>

      <PlaceSearch
        label="From"
        value={originQ}
        placeholder="Current location or an address"
        bias={origin}
        onSelect={fillOrigin}
        onQueryChange={(q) => {
          setOriginQ(q);
          if (origin && q !== origin.label) setOrigin(null);
        }}
      />
      <PlaceSearch
        label="To"
        value={destQ}
        placeholder="Where are you walking?"
        bias={origin}
        onSelect={fillDest}
        onQueryChange={(q) => {
          setDestQ(q);
          if (destination && q !== destination.label) setDestination(null);
        }}
      />

      <div className="flex items-center justify-between rounded-xl bg-surface-2 px-3 py-2.5">
        <div className="flex items-center gap-2">
          <MoonStar className="size-4 text-muted" />
          <div>
            <p className="text-sm font-medium">Night walk</p>
            <p className="text-xs text-muted">Weights lighting and named streets more</p>
          </div>
        </div>
        <Switch checked={night} onCheckedChange={setNight} aria-label="Night walk" />
      </div>

      <div className="flex gap-2">
        <Button
          type="button"
          variant="secondary"
          className="flex-1"
          onClick={() => void locateMe()}
        >
          <LocateFixed className="size-4" />
          {gps === "active" ? "Update location" : "Use location"}
        </Button>
        <Button
          type="button"
          className="flex-[1.4]"
          disabled={planning}
          onClick={() => void runPlan()}
        >
          <Navigation className="size-4" />
          {planning ? "Reading the streets…" : "Find safe path"}
        </Button>
      </div>

      {error && <p className="text-sm text-danger">{error}</p>}

      <div>
        <p className="mb-2 text-xs font-medium text-muted">Try a sample walk</p>
        <SampleRow onPick={pickSample} />
      </div>
    </div>
  );
}
