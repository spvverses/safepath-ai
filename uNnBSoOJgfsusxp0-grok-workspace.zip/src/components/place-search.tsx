import { useEffect, useId, useRef, useState } from "react";
import { MapPin, Search } from "lucide-react";
import { searchPlaces } from "@/lib/api";
import type { LatLng, PlaceHit } from "@/lib/types";
import { cn } from "@/lib/utils";
import { Input } from "@/components/ui/input";

export function PlaceSearch({
  label,
  value,
  placeholder,
  bias,
  onSelect,
  onQueryChange,
}: {
  label: string;
  value: string;
  placeholder: string;
  bias?: LatLng | null;
  onSelect: (place: PlaceHit) => void;
  onQueryChange: (q: string) => void;
}) {
  const id = useId();
  const [open, setOpen] = useState(false);
  const [hits, setHits] = useState<PlaceHit[]>([]);
  const [loading, setLoading] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const q = value.trim();
    if (q.length < 2) {
      setHits([]);
      return;
    }
    let cancelled = false;
    const t = window.setTimeout(() => {
      setLoading(true);
      searchPlaces({
        data: { q, lat: bias?.lat, lng: bias?.lng },
      })
        .then((res) => {
          if (!cancelled) setHits(res);
        })
        .catch(() => {
          if (!cancelled) setHits([]);
        })
        .finally(() => {
          if (!cancelled) setLoading(false);
        });
    }, 280);
    return () => {
      cancelled = true;
      window.clearTimeout(t);
    };
  }, [value, bias?.lat, bias?.lng]);

  useEffect(() => {
    function onDoc(e: MouseEvent) {
      if (!boxRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDoc);
    return () => document.removeEventListener("mousedown", onDoc);
  }, []);

  return (
    <div ref={boxRef} className="relative">
      <label htmlFor={id} className="mb-1.5 block text-xs font-medium text-muted">
        {label}
      </label>
      <div className="relative">
        <Search className="pointer-events-none absolute left-3 top-1/2 size-4 -translate-y-1/2 text-faint" />
        <Input
          id={id}
          value={value}
          placeholder={placeholder}
          autoComplete="off"
          className="pl-9"
          onChange={(e) => {
            onQueryChange(e.target.value);
            setOpen(true);
          }}
          onFocus={() => setOpen(true)}
        />
      </div>
      {open && (hits.length > 0 || loading) && (
        <ul className="absolute z-30 mt-1 max-h-56 w-full overflow-auto rounded-xl bg-surface p-1 shadow-[0_0_0_1px_rgba(241,238,232,0.1),0_16px_40px_rgba(0,0,0,0.45)]">
          {loading && hits.length === 0 && (
            <li className="px-3 py-2 text-xs text-muted">Searching OpenStreetMap…</li>
          )}
          {hits.map((hit) => (
            <li key={hit.id}>
              <button
                type="button"
                className={cn(
                  "flex w-full items-start gap-2 rounded-lg px-3 py-2 text-left hover:bg-surface-2",
                )}
                onClick={() => {
                  onSelect(hit);
                  setOpen(false);
                }}
              >
                <MapPin className="mt-0.5 size-4 shrink-0 text-muted" />
                <span className="min-w-0">
                  <span className="block truncate text-sm text-fg">{hit.name}</span>
                  <span className="block truncate text-xs text-muted">{hit.label}</span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
