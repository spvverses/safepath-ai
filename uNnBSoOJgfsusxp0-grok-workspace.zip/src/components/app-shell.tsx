import { useEffect, useState } from "react";
import { Siren } from "lucide-react";
import { Toaster, toast } from "sonner";
import { MapCanvas } from "@/components/map-canvas";
import { NavPanel } from "@/components/nav-panel";
import { PlannerPanel } from "@/components/planner-panel";
import { ResultsPanel } from "@/components/results-panel";
import { WelcomeGate } from "@/components/welcome-gate";
import { Button } from "@/components/ui/button";
import { useSafePath } from "@/lib/store";
import { useDeviceLocation } from "@/lib/use-location";

function PathMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <path
        d="M7 24c4-2 5-8 3-12 4 1 9 3 12 8 1-5 4-8 8-9"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
      />
      <circle cx="7" cy="24" r="2.1" fill="currentColor" />
      <circle cx="30" cy="11" r="2.1" fill="currentColor" />
    </svg>
  );
}

export function AppShell() {
  const phase = useSafePath((s) => s.phase);
  const origin = useSafePath((s) => s.origin);
  const destination = useSafePath((s) => s.destination);
  const user = useSafePath((s) => s.user);
  const routes = useSafePath((s) => s.routes);
  const selectedId = useSafePath((s) => s.selectedId);
  const amenities = useSafePath((s) => s.amenities);
  const hazards = useSafePath((s) => s.hazards);
  const follow = useSafePath((s) => s.follow);
  const setPhase = useSafePath((s) => s.setPhase);

  useDeviceLocation(phase === "plan" || phase === "results" || phase === "navigate");

  const [invalidate, setInvalidate] = useState<(() => void) | null>(null);
  useEffect(() => {
    invalidate?.();
  }, [phase, invalidate]);

  if (phase === "welcome") return <WelcomeGate />;

  async function headerSos() {
    const pos = user ?? origin;
    if (!pos) {
      toast("Grant location or set a start first.");
      return;
    }
    const text = `I need help. My location: https://www.openstreetmap.org/?mlat=${pos.lat}&mlon=${pos.lng}#map=18/${pos.lat}/${pos.lng}`;
    try {
      await navigator.clipboard.writeText(text);
      toast("Location copied.");
    } catch {
      toast(text);
    }
    window.location.href = "tel:112";
  }

  return (
    <div className="flex h-dvh flex-col bg-bg text-fg">
      <Toaster theme="dark" position="top-center" />
      <header className="z-20 flex items-center justify-between gap-3 border-b border-border px-4 py-3">
        <button type="button" className="flex items-center gap-2" onClick={() => setPhase("welcome")}>
          <PathMark className="size-6" />
          <span className="font-display text-lg tracking-tight">SafePath</span>
        </button>
        <Button variant="danger" size="sm" onClick={() => void headerSos()}>
          <Siren className="size-4" />
          SOS
        </Button>
      </header>

      <div className="grid min-h-0 flex-1 lg:grid-cols-[minmax(20rem,26rem)_1fr]">
        <aside className="order-2 z-10 max-h-[52vh] overflow-y-auto border-t border-border bg-bg px-4 py-4 lg:order-1 lg:max-h-none lg:border-r lg:border-t-0 lg:px-5 lg:py-5">
          {phase === "plan" && <PlannerPanel />}
          {phase === "results" && <ResultsPanel />}
          {phase === "navigate" && <NavPanel />}
        </aside>
        <div className="order-1 min-h-[42vh] lg:order-2 lg:min-h-0">
          <MapCanvas
            origin={origin}
            destination={destination}
            user={user}
            routes={routes}
            selectedId={selectedId}
            amenities={amenities}
            hazards={hazards}
            follow={follow}
            onReady={(fn) => setInvalidate(() => fn)}
          />
        </div>
      </div>
    </div>
  );
}
