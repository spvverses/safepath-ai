import { ArrowLeft, Footprints, ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { KIND_LABEL, useSafePath } from "@/lib/store";
import { formatDistance, formatDuration } from "@/lib/utils";
import { cn } from "@/lib/utils";

function scoreTone(score: number): "safe" | "warn" | "danger" {
  if (score >= 75) return "safe";
  if (score >= 55) return "warn";
  return "danger";
}

export function ResultsPanel() {
  const routes = useSafePath((s) => s.routes);
  const selectedId = useSafePath((s) => s.selectedId);
  const brief = useSafePath((s) => s.brief);
  const night = useSafePath((s) => s.night);
  const setSelected = useSafePath((s) => s.setSelected);
  const setPhase = useSafePath((s) => s.setPhase);
  const resetPlan = useSafePath((s) => s.resetPlan);

  return (
    <div className="space-y-4">
      <div className="flex items-start justify-between gap-3">
        <div>
          <p className="font-display text-2xl tracking-tight">Choose how you walk</p>
          <p className="mt-1 text-sm text-muted">
            {night ? "Night weights are on." : "Daytime weights."} Safest is not always shortest.
          </p>
        </div>
        <Button variant="ghost" size="sm" onClick={resetPlan}>
          <ArrowLeft className="size-4" />
          Edit
        </Button>
      </div>

      <div className="grid gap-2">
        {routes.map((route) => {
          const active = route.id === selectedId;
          return (
            <button
              key={route.id}
              type="button"
              onClick={() => setSelected(route.id)}
              className={cn(
                "rounded-2xl bg-surface-2 p-3 text-left transition-shadow",
                active
                  ? "shadow-[0_0_0_1px_rgba(216,222,230,0.45)]"
                  : "shadow-[0_0_0_1px_rgba(241,238,232,0.06)]",
              )}
            >
              <div className="flex items-center justify-between gap-2">
                <span className="text-sm font-medium">{KIND_LABEL[route.kind]}</span>
                <Badge tone={scoreTone(route.score)}>Safety {route.score}</Badge>
              </div>
              <p className="mt-1 text-xs text-muted">
                {formatDuration(route.duration)} · {formatDistance(route.distance)}
              </p>
              <p className="mt-2 text-sm text-muted">{route.reasons[0]}</p>
            </button>
          );
        })}
      </div>

      {brief && (
        <div className="rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(241,238,232,0.06)]">
          <div className="flex items-center gap-2 text-muted">
            <ShieldCheck className="size-4" />
            <p className="text-xs font-medium uppercase tracking-wider">Safety briefing</p>
          </div>
          <p className="mt-2 font-display text-lg leading-snug tracking-tight">{brief.headline}</p>
          <p className="mt-2 text-sm leading-relaxed text-muted text-pretty">{brief.summary}</p>
          {brief.watchOuts.length > 0 && (
            <ul className="mt-3 space-y-1.5 text-sm text-fg">
              {brief.watchOuts.map((w) => (
                <li key={w} className="flex gap-2">
                  <span className="mt-1 size-1.5 shrink-0 rounded-full bg-warn" />
                  <span>{w}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      )}

      <Button className="w-full" size="lg" onClick={() => setPhase("navigate")}>
        <Footprints className="size-4" />
        Start this walk
      </Button>
    </div>
  );
}
