import { useEffect, useRef } from "react";
import type { Map as LeafletMap, LayerGroup } from "leaflet";
import "leaflet/dist/leaflet.css";
import type { Amenity, Hazard, LatLng, ScoredRoute } from "@/lib/types";

const ROUTE_STYLE: Record<string, { color: string; weight: number; opacity: number; dashArray?: string }> = {
  safest: { color: "#d8dee6", weight: 6, opacity: 0.95 },
  balanced: { color: "#8fa898", weight: 5, opacity: 0.85 },
  fastest: { color: "#6b7380", weight: 4, opacity: 0.7, dashArray: "8 10" },
};

function amenityColor(kind: Amenity["kind"]): string {
  if (kind === "police" || kind === "fire") return "#8fa898";
  if (kind === "hospital" || kind === "clinic" || kind === "pharmacy") return "#d8dee6";
  return "#9aa3ad";
}

export function MapCanvas({
  origin,
  destination,
  user,
  routes,
  selectedId,
  amenities,
  hazards,
  follow,
  onReady,
}: {
  origin: LatLng | null;
  destination: LatLng | null;
  user: LatLng | null;
  routes: ScoredRoute[];
  selectedId: string | null;
  amenities: Amenity[];
  hazards: Hazard[];
  follow: boolean;
  onReady?: (invalidate: () => void) => void;
}) {
  const elRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<LeafletMap | null>(null);
  const layersRef = useRef<LayerGroup | null>(null);
  const userRef = useRef<LayerGroup | null>(null);
  const followRef = useRef(follow);
  followRef.current = follow;

  useEffect(() => {
    const el = elRef.current;
    if (!el) return;
    let cancelled = false;
    let map: LeafletMap | undefined;
    let ro: ResizeObserver | undefined;

    void (async () => {
      const L = await import("leaflet");
      if (cancelled || !elRef.current) return;

      map = L.map(el, {
        zoomControl: false,
        attributionControl: true,
        zoomSnap: 0.5,
      }).setView(user ?? origin ?? { lat: 20.59, lng: 78.96 }, user || origin ? 14 : 4);

      L.tileLayer("https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png", {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> &copy; CARTO',
        subdomains: "abcd",
        maxZoom: 19,
      }).addTo(map);

      L.control.zoom({ position: "topright" }).addTo(map);
      layersRef.current = L.layerGroup().addTo(map);
      userRef.current = L.layerGroup().addTo(map);
      mapRef.current = map;
      map.invalidateSize();
      ro = new ResizeObserver(() => map?.invalidateSize());
      ro.observe(el);
      onReady?.(() => map?.invalidateSize());
    })();

    return () => {
      cancelled = true;
      ro?.disconnect();
      map?.remove();
      mapRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    const group = layersRef.current;
    if (!map || !group) return;
    let cancelled = false;
    void import("leaflet").then((L) => {
      if (cancelled || !mapRef.current || !layersRef.current) return;
      layersRef.current.clearLayers();

      const ordered = [...routes].sort((a, b) =>
        a.id === selectedId ? 1 : b.id === selectedId ? -1 : 0,
      );
      for (const route of ordered) {
        const style = ROUTE_STYLE[route.kind] ?? ROUTE_STYLE.balanced!;
        const isSel = route.id === selectedId;
        L.polyline(
          route.geometry.map((p) => [p.lat, p.lng] as [number, number]),
          {
            color: style.color,
            weight: isSel ? style.weight + 1 : Math.max(3, style.weight - 1),
            opacity: isSel ? style.opacity : 0.35,
            dashArray: style.dashArray,
            lineCap: "round",
            lineJoin: "round",
          },
        ).addTo(layersRef.current!);
      }

      const pin = (point: LatLng, label: string, fill: string) => {
        L.circleMarker([point.lat, point.lng], {
          radius: 8,
          color: "#f1eee8",
          weight: 2,
          fillColor: fill,
          fillOpacity: 1,
        })
          .bindTooltip(label, { direction: "top", offset: [0, -8] })
          .addTo(layersRef.current!);
      };
      if (origin) pin(origin, "Start", "#d8dee6");
      if (destination) pin(destination, "Destination", "#8fa898");

      for (const a of amenities) {
        L.circleMarker([a.lat, a.lng], {
          radius: 5,
          color: amenityColor(a.kind),
          weight: 1,
          fillColor: amenityColor(a.kind),
          fillOpacity: 0.9,
        })
          .bindTooltip(`${a.kind}: ${a.name}`, { direction: "top" })
          .addTo(layersRef.current!);
      }

      for (const h of hazards) {
        L.circleMarker([h.lat, h.lng], {
          radius: 7,
          color: "#c77b6a",
          weight: 2,
          fillColor: "#c77b6a",
          fillOpacity: 0.35,
        })
          .bindTooltip(h.note || h.kind, { direction: "top" })
          .addTo(layersRef.current!);
      }

      const fitPts: [number, number][] = [];
      if (selectedId) {
        const sel = routes.find((r) => r.id === selectedId);
        if (sel) fitPts.push(...sel.geometry.map((p) => [p.lat, p.lng] as [number, number]));
      } else {
        if (origin) fitPts.push([origin.lat, origin.lng]);
        if (destination) fitPts.push([destination.lat, destination.lng]);
      }
      if (fitPts.length >= 2 && !followRef.current) {
        mapRef.current!.fitBounds(fitPts, { padding: [48, 48], maxZoom: 16 });
      } else if (fitPts.length === 1 && !followRef.current) {
        mapRef.current!.setView(fitPts[0], 15);
      }
    });
    return () => {
      cancelled = true;
    };
  }, [routes, selectedId, amenities, hazards, origin, destination]);

  useEffect(() => {
    const group = userRef.current;
    const map = mapRef.current;
    if (!group || !map) return;
    let cancelled = false;
    void import("leaflet").then((L) => {
      if (cancelled || !userRef.current) return;
      userRef.current.clearLayers();
      if (!user) return;
      L.circleMarker([user.lat, user.lng], {
        radius: 18,
        color: "#d8dee6",
        weight: 0,
        fillColor: "#d8dee6",
        fillOpacity: 0.12,
      }).addTo(userRef.current);
      L.circleMarker([user.lat, user.lng], {
        radius: 7,
        color: "#0b0d10",
        weight: 2,
        fillColor: "#f1eee8",
        fillOpacity: 1,
      }).addTo(userRef.current);
      if (followRef.current) {
        map.setView([user.lat, user.lng], Math.max(map.getZoom(), 16), { animate: true });
      }
    });
    return () => {
      cancelled = true;
    };
  }, [user]);

  return <div ref={elRef} className="map-root h-full w-full" />;
}
