import { useMemo } from "react";
import { Flag, OctagonX, Radio } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { nearestOnPath, remainingDistance } from "@/lib/geo";
import { HAZARD_LABEL, useSafePath } from "@/lib/store";
import { formatDistance, formatDuration } from "@/lib/utils";
import type { HazardKind } from "@/lib/types";

export function NavPanel() {
  const route = useSafePath((s) => s.selectedRoute());
  const user = useSafePath((s) => s.user);
  const origin = useSafePath((s) => s.origin);
  const destination = useSafePath((s) => s.destination);
  const setPhase = useSafePath((s) => s.setPhase);
  const addHazard = useSafePath((s) => s.addHazard);
  const gps = useSafePath((s) => s.gps);

  const pos = user ?? (origin ? { lat: origin.lat, lng: origin.lng } : null);

  const nav = useMemo(() => {
    if (!route || !pos) {
      return {
        instruction: route?.steps[0]?.instruction ?? "Follow the highlighted path",
        remainingM: route?.distance ?? 0,
        remainingS: route?.duration ?? 0,
        off: false,
      };
    }
    const near = nearestOnPath(pos, route.geometry);
    const remainingM = remainingDistance(pos, route.geometry);
    const pace = route.distance > 0 ? route.duration / route.distance : 0;
    let walked = 0;
    let step = route.steps[0];
    for (const s of route.steps) {
      if (walked + s.distance >= near.along) {
        step = s;
        break;
      }
      walked += s.distance;
    }
    return {
      instruction: step?.instruction ?? "Continue on the safe path",
      remainingM,
      remainingS: remainingM * pace,
      off: near.dist > 55,
    };
  }, [route, pos]);

  async function sos() {
    if (!pos) {
      toast("We don't have a location to share yet.");
      return;
    }
    const text = `I need help. My location: https://www.openstreetmap.org/?mlat=${pos.lat}&mlon=${pos.lng}#map=18/${pos.lat}/${pos.lng}`;
    try {
      if (navigator.share) {
        await navigator.share({ text });
      } else {
        await navigator.clipboard.writeText(text);
        toast("Location copied. Send it to someone you trust.");
      }
    } catch {
      try {
        await navigator.clipboard.writeText(text);
        toast("Location copied.");
      } catch {
        toast(text);
      }
    }
    window.location.href = "tel:112";
  }

  function mark(kind: HazardKind) {
    const point = pos ?? destination;
    if (!point) return;
    addHazard(kind, point, HAZARD_LABEL[kind]);
    toast("Hazard saved on this device for later walks.");
  }

  if (!route) return null;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Badge tone={gps === "active" ? "safe" : "muted"}>
          {gps === "active" ? "Live location on" : "Location not following yet"}
        </Badge>
        <p className="text-xs tabular-nums text-muted">
          {formatDuration(nav.remainingS)} · {formatDistance(nav.remainingM)}
        </p>
      </div>

      <div>
        <p className="text-xs font-medium uppercase tracking-wider text-muted">Next</p>
        <p className="mt-1 font-display text-2xl leading-tight tracking-tight text-balance" aria-live="polite">
          {nav.instruction}
        </p>
        {nav.off && (
          <p className="mt-2 text-sm text-warn">
            You are off the safe path. Return to the highlighted streets, or plan again from here.
          </p>
        )}
      </div>

      <div className="grid grid-cols-2 gap-2">
        <Button variant="danger" onClick={() => void sos()}>
          <Radio className="size-4" />
          SOS · 112
        </Button>
        <Button variant="secondary" onClick={() => setPhase("results")}>
          <OctagonX className="size-4" />
          End walk
        </Button>
      </div>

      <div>
        <p className="mb-2 flex items-center gap-1.5 text-xs font-medium text-muted">
          <Flag className="size-3.5" />
          Mark a hazard here
        </p>
        <div className="flex flex-wrap gap-2">
          {(Object.keys(HAZARD_LABEL) as HazardKind[]).map((kind) => (
            <button
              key={kind}
              type="button"
              onClick={() => mark(kind)}
              className="rounded-full bg-surface-2 px-3 py-1.5 text-xs text-muted shadow-[0_0_0_1px_rgba(241,238,232,0.08)] hover:text-fg"
            >
              {HAZARD_LABEL[kind]}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
