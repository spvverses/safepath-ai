import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

export function Badge({
  className,
  tone = "muted",
  children,
}: {
  className?: string;
  tone?: "muted" | "safe" | "warn" | "danger" | "fg";
  children: ReactNode;
}) {
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full px-2 py-0.5 text-xs font-medium tracking-wide",
        tone === "muted" && "bg-surface-2 text-muted",
        tone === "safe" && "bg-safe/15 text-safe",
        tone === "warn" && "bg-warn/15 text-warn",
        tone === "danger" && "bg-danger/15 text-danger",
        tone === "fg" && "bg-primary/12 text-fg",
        className,
      )}
    >
      {children}
    </span>
  );
}
