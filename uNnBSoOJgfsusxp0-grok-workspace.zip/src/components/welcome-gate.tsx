import { Moon, Shield, Lamp, MapPinned } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SAMPLE_WALKS } from "@/lib/samples";
import { requestLocationOnce } from "@/lib/use-location";
import { reverseGeocode } from "@/lib/api";
import { useSafePath } from "@/lib/store";

function PathMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-8" aria-hidden="true">
      <path
        d="M7 24c4-2 5-8 3-12 4 1 9 3 12 8 1-5 4-8 8-9"
        fill="none"
        stroke="currentColor"
        strokeWidth="1.7"
        strokeLinecap="round"
      />
      <circle cx="7" cy="24" r="2.1" fill="currentColor" />
      <circle cx="30" cy="11" r="2.1" fill="currentColor" />
    </svg>
  );
}

export function WelcomeGate() {
  const setPhase = useSafePath((s) => s.setPhase);
  const setOrigin = useSafePath((s) => s.setOrigin);
  const setDestination = useSafePath((s) => s.setDestination);
  const setUser = useSafePath((s) => s.setUser);
  const setGps = useSafePath((s) => s.setGps);

  async function useLocation() {
    setGps("asking");
    const point = await requestLocationOnce();
    if (!point) {
      setGps("denied");
      setPhase("plan");
      return;
    }
    setUser(point);
    setGps("active");
    setOrigin({
      id: "gps",
      name: "Current location",
      label: `${point.lat.toFixed(5)}, ${point.lng.toFixed(5)}`,
      lat: point.lat,
      lng: point.lng,
    });
    setPhase("plan");
    try {
      const r = await reverseGeocode({ data: point });
      setOrigin({
        id: "gps",
        name: "Current location",
        label: r.label,
        lat: point.lat,
        lng: point.lng,
      });
    } catch {
      /* keep coordinates */
    }
  }

  return (
    <div className="relative flex min-h-dvh flex-col bg-bg text-fg">
      <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(216,222,230,0.08),transparent_55%)]" />
      <div className="relative mx-auto flex w-full max-w-lg flex-1 flex-col justify-between px-6 py-8 sm:py-12">
        <header className="flex items-center gap-3 text-fg">
          <PathMark />
          <div>
            <p className="font-display text-xl leading-tight tracking-tight">SafePath</p>
            <p className="text-xs text-muted">Safer walks than the fastest route</p>
          </div>
        </header>

        <div className="py-10">
          <h1 className="font-display text-4xl leading-tight tracking-tight text-balance sm:text-5xl">
            Google Maps gets you there fastest.
            <span className="text-muted"> SafePath gets you there safer.</span>
          </h1>
          <p className="mt-5 max-w-md text-sm leading-relaxed text-muted text-pretty">
            Shortcuts through unlit alleys, empty service roads, and quiet parks look efficient on a
            timer. They are a poor idea on the walk home. SafePath ranks OpenStreetMap walking paths
            by lighting, named streets, people, and help nearby.
          </p>

          <ul className="mt-8 grid gap-3">
            {[
              { icon: Lamp, title: "Lighting over shortcuts", body: "Night walks prefer lit, named streets — not the alley that saves ninety seconds." },
              { icon: Shield, title: "Help on the map", body: "Police, hospitals, clinics, and pharmacies from OpenStreetMap sit on the route." },
              { icon: Moon, title: "A live companion", body: "Turn-by-turn, a safety briefing, and an SOS that shares where you are." },
            ].map((item) => (
              <li key={item.title} className="flex gap-3 rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(241,238,232,0.06)]">
                <item.icon className="mt-0.5 size-4 shrink-0 text-muted" />
                <div>
                  <p className="text-sm font-medium">{item.title}</p>
                  <p className="mt-1 text-sm text-muted">{item.body}</p>
                </div>
              </li>
            ))}
          </ul>
        </div>

        <div className="space-y-3">
          <Button className="w-full" size="lg" onClick={() => void useLocation()}>
            <MapPinned className="size-4" />
            Use my location
          </Button>
          <Button className="w-full" size="lg" variant="secondary" onClick={() => setPhase("plan")}>
            Plan a walk instead
          </Button>
          <p className="pt-1 text-center text-xs text-faint">
            OpenStreetMap · OSRM · Overpass — no account, no tracking login
          </p>
        </div>
      </div>
    </div>
  );
}

export function SampleRow({ onPick }: { onPick: (id: string) => void }) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      {SAMPLE_WALKS.map((w) => (
        <button
          key={w.id}
          type="button"
          onClick={() => onPick(w.id)}
          className="shrink-0 rounded-full bg-surface-2 px-3 py-1.5 text-xs text-muted shadow-[0_0_0_1px_rgba(241,238,232,0.08)] hover:text-fg"
        >
          {w.city}
        </button>
      ))}
    </div>
  );
}
